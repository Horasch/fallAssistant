/**
 * \file screens_common.h
 * \version 1.00
 * \brief this file contains common screen objects' and structures' declarations
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * Neither the name of NXP, nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * visit: http://www.mikroe.com and http://www.nxp.com
 *
 * get support at: http://www.mikroe.com/forum and https://community.nxp.com
 *
 * Project HEXIWEAR, 2015
 */

#pragma once

#include <stdint.h>
#include "OLED_driver.h"

#include "watch.h"

#include "apps.h"

#include "gui_weatherStation.h"
//#include "airQuality.h"
#include "gui_motionControl.h"
#include "fitness.h"
#include "gui_pedometer.h"
#include "gui_heartRate.h"
#include "flashlight.h"
//#include "ambilight.h"
#include "fallAssistant.h"
#include "fallData.h"
#include "fallConfig.h"
#include "gui_notifications.h"
#include "settings.h"
#include "bluetooth.h"
#include "bootloader.h"
#include "buttons_group.h"
#include "haptic.h"
#include "getApp.h"
#include "googleApp.h"
#include "iOSApp.h"
#include "about.h"
#include "info.h"
#include "reset.h"
//#include "battery.h"
#include "bond.h"
#include "gui_sensorTag.h"
#include "power.h"

#define SCREEN_BYTE_SIZE ( OLED_SCREEN_WIDTH * OLED_SCREEN_HEIGHT * OLED_BYTES_PER_PIXEL )

extern guiLabel_t screen_label;
extern guiLabel_t screen_labelEnter;
extern guiLabel_t screen_labelBack;

extern uint8_t bluedot_bmp[8];
extern uint8_t blackdot_bmp[8];
extern uint8_t whitedot_bmp[8];
extern uint8_t reddot_bmp[8];

extern const uint8_t black_bmp[14];
extern const uint8_t blue_bmp[14];
extern const uint8_t blue2_bmp[14];
extern const uint8_t cyan_bmp[14];
extern const uint8_t green_bmp[14];
extern const uint8_t magenta_bmp[14];
extern const uint8_t orange_bmp[14];
extern const uint8_t red_bmp[14];
extern const uint8_t white_bmp[14];
extern const uint8_t yellow_bmp[14];


extern const uint8_t button_play_bmp[518];
extern const uint8_t button_pause_bmp[518];
extern const uint8_t button_back16_bmp[518];
extern const uint8_t button_ok_bmp[518];
extern const uint8_t button_up_bmp[518];
extern const uint8_t button_down_bmp[518];
extern const uint8_t button_touch_bmp[518];
extern const uint8_t button_no_bmp[518];
extern const uint8_t button_on_off_bmp[518];
extern const uint8_t button_next_bmp[518];

//old button images have to be changed or deleted
//extern const uint8_t button_left_back_bmp[1064];
extern const uint8_t button_back_bmp[1416];
extern const uint8_t button_stop_bmp[1386];
extern const uint8_t button_start_disabled_bmp[1386];
extern const uint8_t button_start_bmp[1386];
extern const uint8_t button_back_disabled_bmp[1416];
extern const uint8_t button_reset_bmp[1386];

extern guiImage_t screen_imgBackground;
extern guiImage_t screen_imgIcon;

extern guiImage_t screen_buttonStart;
extern guiImage_t screen_buttonStartDisabled;
extern guiImage_t screen_buttonPlay;
extern guiImage_t screen_buttonPause;
extern guiImage_t screen_buttonStop;
extern guiImage_t screen_buttonReset;
extern guiImage_t screen_buttonBack;
extern guiImage_t screen_buttonOk;
extern guiImage_t screen_buttonUp;
extern guiImage_t screen_buttonDown;
extern guiImage_t screen_buttonTouch;
extern guiImage_t screen_buttonNo;
extern guiImage_t screen_buttonOnOff;
extern guiImage_t screen_buttonLeftBack;
extern guiImage_t screen_buttonNext;
extern guiImage_t screen_buttonBackDisabled;

extern guiImage_t screen_buttonRightUp;
extern guiImage_t screen_buttonRightDown;
extern guiImage_t screen_buttonLeftUp;
extern guiImage_t screen_buttonLeftDown;

extern const uint8_t
   hexiwear_logo_bmp[ OLED_GRAM_SIZE + 6 ],
   blank_cover_bmp[ OLED_GRAM_SIZE + 6 ],
   blank_screen_bmp[ OLED_GRAM_SIZE + 6 ],
   buttonGroup_right_bmp[36],
   buttonGroup_left_bmp[36];

extern guiScreen_t
  splashScreen;

/*
 * fallConfig_driver.c
 *
 *  Created on: 02.09.2016
 *      Author: Juri
 */


#include "fallConfig.h"
#include "fallConfig_private.h"
#include "screens_common.h"
#include "haptic.h"
#include "FLASH_driver.h"
#include "fallAssistant.h"

/** private variables */

static task_handler_t
    fallConfig_taskHandler;

static hostInterface_packet_t
        fallConfig_packet;

/** private declarations */

static void fallConfig_AppTask();
static void fallConfig_TimeFrameCalc(uint8_t minPollDelayValue, uint8_t* ptr_frameTime);
static void fallConfig_Cursor(uint8_t menuRow);
/** public API */

/**
 * initialize the fall config app
 * @param param optional parameter
 */
void fallConfig_Cover_Init( void* param )
{
	screen_imgIcon.img = fallConfig_icon_bmp;
	GuiDriver_ImageAddToScr( &screen_imgIcon );
   	GuiDriver_ImageAddToScr( &screen_buttonOk );

    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Fall Config" );
    GuiDriver_LabelDraw( &screen_label );
}

void fallConfig_Init( void* param )
{
    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelDraw( &screen_label );

    GuiDriver_LabelCreate( &fallConfig_labelLimitText );
    GuiDriver_LabelSetCaption( &fallConfig_labelLimitText, (uint8_t*)"Alarm Lim:" );
    GuiDriver_LabelDraw( &fallConfig_labelLimitText );
	GuiDriver_LabelCreate( &fallConfig_labelLimit );

    GuiDriver_LabelCreate( &fallConfig_labelSumText );
    GuiDriver_LabelSetCaption( &fallConfig_labelSumText, (uint8_t*)"Alarm Sum:" );
    GuiDriver_LabelDraw( &fallConfig_labelSumText );
	GuiDriver_LabelCreate( &fallConfig_labelSum );

    GuiDriver_LabelCreate( &fallConfig_labelDelayText );
    GuiDriver_LabelSetCaption( &fallConfig_labelDelayText, (uint8_t*)"Poll Delay:" );
    GuiDriver_LabelDraw( &fallConfig_labelDelayText );
    GuiDriver_LabelCreate( &fallConfig_labelDelay );

    GuiDriver_LabelCreate( &fallConfig_charOut );
   	GuiDriver_ImageAddToScr( &screen_buttonTouch );

	GuiDriver_RegisterForNavigation( GUI_NAVIGATION_UP );
	GuiDriver_RegisterForNavigation( GUI_NAVIGATION_DOWN );
    GuiDriver_RegisterForNavigation( GUI_NAVIGATION_RIGHT );

    fallAssistant_ReadConfigData( &flashMeasDataAddress, &alarmCounter, &alarmLimit, &alarmSumLimit, &minPollDelayValue );
}

/**
 * create the app main task
 * @param param optional parameter
 */
void fallConfig_CreateTasks( void* param )
{
    osa_status_t
        taskStatus = OSA_TaskCreate(
                                        fallConfig_AppTask,
                                        (uint8_t*) "fall config",
                                        FALL_CONFIG_STACK_SIZE,
                                        NULL,
                                        FALL_CONFIG_PRIO,
                                        (task_param_t)0,
                                        false,
                                        &fallConfig_taskHandler
                                    );

    if ( kStatus_OSA_Success != taskStatus )
    {
        catch( CATCH_INIT );
    }
}

/**
 * destroy the app task
 * @param param optional parameter
 */
void fallConfig_DestroyTasks( void* param )
{
	if( flashMeasDataAddress == EXT_FLASH_MEAS_DATA_ADDRESS )
	{
		while( STATUS_FLASH_SUCCESS !=  FLASH_EraseSector( EXT_FLASH_MEAS_DATA_ADDRESS ) );
	}
    fallAssistant_SaveConfigData( flashMeasDataAddress, alarmCounter, alarmLimit, alarmSumLimit, minPollDelayValue );

    OSA_TaskDestroy( fallConfig_taskHandler );
    OLED_DestroyDynamicArea();

    GuiDriver_LabelDestroy( &screen_label );
    GuiDriver_LabelDestroy( &fallConfig_labelLimitText );
	GuiDriver_LabelDestroy( &fallConfig_labelLimit );
    GuiDriver_LabelDestroy( &fallConfig_labelSumText );
	GuiDriver_LabelDestroy( &fallConfig_labelSum );
    GuiDriver_LabelDestroy( &fallConfig_labelDelayText );
    GuiDriver_LabelDestroy( &fallConfig_labelDelay );
    GuiDriver_LabelDestroy( &fallConfig_charOut );

    GuiDriver_UnregisterFromNavigation( GUI_NAVIGATION_UP );
    GuiDriver_UnregisterFromNavigation( GUI_NAVIGATION_DOWN );
    GuiDriver_UnregisterFromNavigation( GUI_NAVIGATION_RIGHT );

    power_EnablePowerSave();
}

/** private API */

/**
 * fall assistant main task, charged with
 * getting data from sensors and displaying them
 */
static void fallConfig_AppTask()
{
	power_DisablePowerSave();

	uint8_t frameTime = 0;										// Value for Timeframe calculation
	uint8_t menuRow = 1;

	if( flashMeasDataAddress > 0x1FF00 )
	{
			alarmCounter = 0;									// init values for first run
			alarmLimit = 20;
			alarmSumLimit = 400;
			minPollDelayValue = 3;
			flashMeasDataAddress = EXT_FLASH_MEAS_DATA_ADDRESS;
	}
	fallConfig_TimeFrameCalc(minPollDelayValue, &frameTime);

	while (1)													// draw menu
    {
		snprintf( (char*)fallConfig_labelLimit.caption, 6, "%i.%01i g", alarmLimit / 10, alarmLimit % 10 );
		GuiDriver_LabelDraw( &fallConfig_labelLimit );
		snprintf( (char*)fallConfig_labelSum.caption, 6, "%d g", alarmSumLimit / 10 );
		GuiDriver_LabelDraw( &fallConfig_labelSum );
		snprintf( (char*)fallConfig_labelDelay.caption, 7, "%d ms" , minPollDelayValue );
		GuiDriver_LabelDraw( &fallConfig_labelDelay );
		snprintf( (char*)fallConfig_charOut.caption, 22, "capture time: %i.%01i s", frameTime / 10, frameTime % 10 );
		GuiDriver_LabelDraw( &fallConfig_charOut );
		fallConfig_Cursor(menuRow);

		gui_status_t
			clickStatus = GuiDriver_QueueMsgGet( &fallConfig_packet , OSA_WAIT_FOREVER );

        if( GUI_STATUS_SUCCESS == clickStatus )
        {

            if( packetType_pressUp == fallConfig_packet.type ) // increase values
            {
				switch( menuRow )
				{
					case 1:
					{
						if( alarmLimit < 70 )
						{
							alarmLimit ++;
						}
						break;
					}
					case 2:
					{
						if( alarmSumLimit < 5000 )
						{
							alarmSumLimit += 10;
						}
						break;
					}
					case 3:
					{
						if( minPollDelayValue < 10 )
						{
							minPollDelayValue ++;
							fallConfig_TimeFrameCalc(minPollDelayValue, &frameTime);
						}
						break;
					}
					default: {}
            	}
            }

            if( packetType_pressDown == fallConfig_packet.type )		// decrease values
            {
				switch( menuRow )
				{
					case 1:
					{
						if( alarmLimit > 10 )
						{
							alarmLimit --;
						}
						break;
					}
					case 2:
					{
						if( alarmSumLimit > 110 )
						{
							alarmSumLimit -= 10;
						}
						break;
					}
					case 3:
					{
						if( minPollDelayValue > 3 )
						{
							minPollDelayValue --;
							fallConfig_TimeFrameCalc(minPollDelayValue, &frameTime);
						}
						break;
					}
					default: {}
				}
            }

            if( packetType_pressRight == fallConfig_packet.type ) // move the cursor through the menu
            {
            	if( menuRow < 3 )
            	{
            		menuRow++;
            	}
            	else
            	{
            		menuRow = 1;
            	}
				fallConfig_Cursor(menuRow);
            }
        }
    }
}

static void fallConfig_Cursor(uint8_t menuRow)				// move the cursor
{
	fallAssistant_pixel.dynamicArea.xCrd = 1 ;

	switch( menuRow )
	{
		case 1:
		{
			fallAssistant_pixel.img = black_bmp;
    		fallAssistant_pixel.dynamicArea.yCrd = 41;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
    		fallAssistant_pixel.dynamicArea.yCrd = 54;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.img = red_bmp;
        	fallAssistant_pixel.dynamicArea.yCrd = 28;
	        GuiDriver_ImageDraw(&fallAssistant_pixel);
			break;
		}
		case 2:
		{
			fallAssistant_pixel.img = black_bmp;
			fallAssistant_pixel.dynamicArea.yCrd = 28;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.dynamicArea.yCrd = 54;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.img = red_bmp;
        	fallAssistant_pixel.dynamicArea.yCrd = 41;
	        GuiDriver_ImageDraw(&fallAssistant_pixel);
			break;
		}
		case 3:
		{
			fallAssistant_pixel.img = black_bmp;
			fallAssistant_pixel.dynamicArea.yCrd = 28;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.dynamicArea.yCrd = 41;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.img = red_bmp;
        	fallAssistant_pixel.dynamicArea.yCrd = 54;
	        GuiDriver_ImageDraw(&fallAssistant_pixel);
			break;
		}
		default: {}
	}
}

static void fallConfig_TimeFrameCalc(uint8_t minPollDelayValue, uint8_t* ptr_frameTime)
{
	if( minPollDelayValue < 4 )
	{
		*ptr_frameTime = 10;					// Timeframe for one data array in seconds * 10
	}
	else if( minPollDelayValue < 6 )
	{
		*ptr_frameTime = 15;					// Timeframe for one data array in seconds * 10
	}
	else if( minPollDelayValue < 8 )
	{
		*ptr_frameTime = 20;					// Timeframe for one data array in seconds * 10
	}
	else if( minPollDelayValue < 10 )
	{
		*ptr_frameTime = 26;					// Timeframe for one data array in seconds * 10
	}
	else if( minPollDelayValue == 10 )
	{
		*ptr_frameTime = 30;					// Timeframe for one data array in seconds * 10
	}

}


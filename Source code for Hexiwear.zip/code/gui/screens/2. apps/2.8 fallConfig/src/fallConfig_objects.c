/*
 * fallConfig_objects.c
 *
 *  Created on: 02.09.2016
 *      Author: Juri
 */

#include "screens_common.h"
#include "fallConfig_private.h"
#include "fallConfig.h"

static guiScreen_t
	fallConfig_mainScreen;

guiScreen_t
    fallConfig_coverScreen =
    {
        .navigation =
        {
            .up     = &fallAssistant_coverScreen,
            .down   = &fallData_coverScreen,
            .left   = &appsScreen,
            .right  = &fallConfig_mainScreen
        },

        .image = blank_cover_bmp,

        .initFunction        = fallConfig_Cover_Init,
        .createTaskFunction  = NULL,
        .destroyTaskFunction = NULL
    };

static guiScreen_t
    fallConfig_mainScreen =
    {
        .navigation =
        {
            .up     = NULL,
            .down   = NULL,
            .left   = &fallConfig_coverScreen,
            .right  = NULL
        },

        .image = blank_screen_bmp,

        .initFunction        = fallConfig_Init,
        .createTaskFunction  = fallConfig_CreateTasks,
        .destroyTaskFunction = fallConfig_DestroyTasks
    };

/** labels */

/** alarm limit */
guiLabel_t fallConfig_labelLimitText =
{
    .dynamicArea =
    {
        .xCrd   = 6,
        .yCrd   = 22,
        .width  = 55,
        .height = 13
    },
    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_ORANGE_1,
        .alignParam = OLED_TEXT_ALIGN_LEFT,
        .background = blank_screen_bmp
    },
    .caption = NULL,
    .captionLength = 10
};

guiLabel_t fallConfig_labelLimit =
{
    .dynamicArea =
    {
        .xCrd   = 65,
        .yCrd   = 22,
        .width  = 27,
        .height = 13
    },
    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_WHITE,
        .alignParam = OLED_TEXT_ALIGN_RIGHT,
        .background = blank_screen_bmp
    },
    .caption = NULL,
    .captionLength = 6
};

/** alarm sum value */
guiLabel_t fallConfig_labelSumText =
{
    .dynamicArea =
    {
        .xCrd   = 6,
        .yCrd   = 35,
        .width  = 55,
        .height = 13
    },
    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_ORANGE_1,
        .alignParam = OLED_TEXT_ALIGN_LEFT,
        .background = blank_screen_bmp
    },
    .caption = NULL,
    .captionLength = 10
};

guiLabel_t fallConfig_labelSum =
{
    .dynamicArea =
    {
        .xCrd   = 65,
        .yCrd   = 35,
        .width  = 27,
        .height = 13
    },
    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_WHITE,
        .alignParam = OLED_TEXT_ALIGN_RIGHT,
        .background = blank_screen_bmp
    },
    .caption = NULL,
    .captionLength = 6
};

/** poll delay value */
guiLabel_t fallConfig_labelDelayText =
{
    .dynamicArea =
    {
        .xCrd   = 6,
        .yCrd   = 48,
        .width  = 54,
        .height = 13
    },
    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_ORANGE_1,
        .alignParam = OLED_TEXT_ALIGN_LEFT,
        .background = blank_screen_bmp
    },
    .caption = NULL,
    .captionLength = 11
};

guiLabel_t fallConfig_labelDelay =
{
    .dynamicArea =
    {
        .xCrd   = 65,
        .yCrd   = 48,
        .width  = 27,
        .height = 13
    },
    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_WHITE,
        .alignParam = OLED_TEXT_ALIGN_RIGHT,
        .background = blank_screen_bmp
    },
    .caption = NULL,
    .captionLength = 7
};


guiLabel_t fallConfig_charOut =
{
    .dynamicArea =
    {
        .xCrd   = 1,
        .yCrd   = 61,
        .width  = 94,
        .height = 13
    },

    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_LIGHT_GRAY,
        .alignParam = OLED_TEXT_ALIGN_CENTER,
        .background = blank_screen_bmp
    },

    .caption = NULL,
    .captionLength = 20
};







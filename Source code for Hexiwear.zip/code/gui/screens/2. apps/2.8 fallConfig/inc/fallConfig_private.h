/**
 * \file fallConfig_private.h
 * \version 1.00
 * \Juri Kuebler
 * \09.2016
 */

#pragma once

#include <stdint.h>
#include "gui_driver.h"

extern const uint8_t
    fallConfig_icon_bmp[ 5006 ];

extern guiLabel_t
	fallConfig_charOut,
	fallConfig_labelLimitText,
	fallConfig_labelLimit,
	fallConfig_labelSumText,
	fallConfig_labelSum,
	fallConfig_labelDelayText,
	fallConfig_labelDelay;


#pragma once

#include "gui_driver.h"

#define FALL_CONFIG_STACK_SIZE				( 0x500 )
#define FALL_CONFIG_PRIO					( HEXIWEAR_GUI_PRIO )
#define EXT_FLASH_APP_CONFIG_ADDRESS		( 0xE0000 )
#define EXT_FLASH_MEAS_DATA_ADDRESS			( 0x10000 )


extern guiScreen_t
	fallConfig_coverScreen;

void fallConfig_Cover_Init();
void fallConfig_Init();
void fallConfig_CreateTasks();
void fallConfig_DestroyTasks();

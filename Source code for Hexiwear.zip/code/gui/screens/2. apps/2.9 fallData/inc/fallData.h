/**
 * \file fallData.h
 * \version 1.00
 * \Juri Kuebler
 * \08.2016
 */


#pragma once

#include "gui_driver.h"

#define FALL_DATA_STACK_SIZE  ( 0x400 )

#define FALL_DATA_PRIO  ( HEXIWEAR_GUI_PRIO )

extern guiScreen_t
	fallData_coverScreen;

void fallData_Init();
void fallData_Cover_Init();
void fallData_CreateTasks();
void fallData_DestroyTasks();

/**
 * \file fallData_private.h
 * \version 1.00
 * \Juri Kuebler
 * \08.2016
 */

#pragma once

#include "gui_driver.h"
#include <stdint.h>


extern const uint8_t
	fallData_icon_bmp[ 5006 ],
	fallData_graph_orange_bmp[ 390 ];

extern guiLabel_t
	fallData_alarm_label,
	fallData_charOut;

/*
 * fallData_driver.c
 *
 *  Created on: 02.09.2016
 *      Author: Juri
 */

#include "fallData.h"
#include "fallData_private.h"
#include "screens_common.h"
#include "FLASH_driver.h"
#include "fallAssistant.h"
#include "OLED_driver.h"

#include "DEBUG_UART.h"
#include "test_uart.h"

/** private variables */

static task_handler_t
    fallData_taskHandler;

static hostInterface_packet_t
    fallData_packet;

static rtc_datetime_t
	data_time;

/** private declarations */

static void fallData_AppTask();
static void fallData_DrawGraph( uint8_t accDataArray[], uint8_t startIndex, uint8_t stopIndex, uint8_t alarmLimit );
static void fallData_ReadAlarmData( uint8_t accDataArray[], uint8_t* ptr_alarmDataNumber, uint8_t* ptr_accMaxData, uint8_t* ptr_accAvgData,
		uint8_t* ptr_alarmLimitData, uint16_t* ptr_alarmSumLimitData, uint16_t* ptr_alarmSumData, uint8_t* ptr_minPollDelayData );
static void fallData_View( uint8_t viewPosition, uint8_t* ptr_startIndex, uint8_t* ptr_stopIndex);
static void fallData_Header( uint8_t accMaxData, uint8_t accAvgData, uint8_t alarmLimitData, uint16_t alarmSumLimitData,
		uint16_t alarmSumData, uint8_t minPollDelayData );
/**
 * initialize the fall data app
 * @param param optional parameter
 */

void fallData_Cover_Init( void* param )
{
    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Fall Data" );
    GuiDriver_LabelDraw( &screen_label );

	screen_imgIcon.img = fallData_icon_bmp;
	GuiDriver_ImageAddToScr( &screen_imgIcon );
   	GuiDriver_ImageAddToScr( &screen_buttonNext );

    GuiDriver_LabelCreate( &screen_label );
}

void fallData_Init( void* param )
{
    GuiDriver_LabelCreate( &fallData_alarm_label );
    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelCreate( &fallData_charOut );
    GuiDriver_ImageDraw( &screen_buttonTouch );

	GuiDriver_RegisterForNavigation( GUI_NAVIGATION_UP );
    GuiDriver_RegisterForNavigation( GUI_NAVIGATION_DOWN );
    GuiDriver_RegisterForNavigation( GUI_NAVIGATION_RIGHT );

	power_DisablePowerSave();
}
void fallData_CreateTasks( void* param )
{
    osa_status_t
        taskStatus = OSA_TaskCreate(
                                        fallData_AppTask,
                                        (uint8_t*) "fall data",
                                        FALL_DATA_STACK_SIZE,
                                        NULL,
                                        FALL_DATA_PRIO,
                                        (task_param_t)0,
                                        false,
                                        &fallData_taskHandler
                                    );

    if ( kStatus_OSA_Success != taskStatus )
    {
        catch( CATCH_INIT );
    }
}

void fallData_DestroyTasks( void* param )
{
	GuiDriver_LabelDestroy( &screen_label );
    GuiDriver_LabelDestroy( &fallData_alarm_label );
    GuiDriver_LabelDestroy( &fallData_charOut );
    OLED_DestroyDynamicArea();

    GuiDriver_UnregisterFromNavigation( GUI_NAVIGATION_UP );
    GuiDriver_UnregisterFromNavigation( GUI_NAVIGATION_DOWN );
    GuiDriver_UnregisterFromNavigation( GUI_NAVIGATION_RIGHT );

    OSA_TaskDestroy( fallData_taskHandler );
    power_EnablePowerSave();
}

/** private API */

/**
 * fall data main task, charged with
 * getting data from sensors and displaying them
 */
static void fallData_AppTask()
{
	static uint32_t flashMeasDataViewAddress = 0;

	static uint8_t accDataArray[256];
	static uint8_t alarmDataNumber = 0;
	static uint8_t accMaxData = 0;
	static uint8_t accAvgData = 0;
	static uint8_t alarmLimitData = 0;
	static uint16_t alarmSumLimitData = 0;
	static uint16_t alarmSumData = 0;
	static uint8_t minPollDelayData = 0;

	static uint8_t startIndex = 0;
	static uint8_t stopIndex = 95;
	uint8_t viewPosition = 1;
	uint8_t drawNewData = 1;

	fallAssistant_ReadConfigData( &flashMeasDataAddress, &alarmCounter, &alarmLimit, &alarmSumLimit, &minPollDelayValue );
	flashMeasDataViewAddress = flashMeasDataAddress - 0x100;

	while (1)
	    {

			if( drawNewData )
			{
				while( STATUS_FLASH_SUCCESS != FLASH_ReadData( flashMeasDataViewAddress, accDataArray, sizeof(accDataArray) ) ) {};
				fallData_View( viewPosition, &startIndex, &stopIndex);
				fallData_ReadAlarmData( accDataArray, &alarmDataNumber, &accMaxData, &accAvgData, &alarmLimitData, &alarmSumLimitData, &alarmSumData, &minPollDelayData );

				if( minPollDelayData > 10)
				{
					GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"No Data" );
					GuiDriver_LabelDraw( &screen_label );
					snprintf( (char*)fallData_alarm_label.caption, 6, "%c", 33 );
					GuiDriver_LabelDraw( &fallData_alarm_label );
				}
				else
				{
					snprintf( (char*)screen_label.caption, 15, "%02d.%02d %02d:%02d:%02d", data_time.day, data_time.month, data_time.hour, data_time.minute, data_time.second );
					GuiDriver_LabelDraw( &screen_label );
					snprintf( (char*)fallData_alarm_label.caption, 6, "%d", alarmDataNumber );
					GuiDriver_LabelDraw( &fallData_alarm_label );

					if( viewPosition == 3)
					{
						fallData_Header( accMaxData, accAvgData, alarmLimitData, alarmSumLimitData, alarmSumData, minPollDelayData );
						while( kStatus_UART_Success != UART_DRV_SendDataBlocking( FSL_DEBUG_UART, (char*)fallData_alarm_label.caption , 3 , UART_TIMEOUT) );
						while( kStatus_UART_Success != UART_DRV_SendDataBlocking( FSL_DEBUG_UART, (char*)screen_label.caption , 15 , UART_TIMEOUT) );
						while( kStatus_UART_Success != UART_DRV_SendDataBlocking( FSL_DEBUG_UART, accDataArray, sizeof(accDataArray), UART_TIMEOUT) );
					}

					fallData_DrawGraph( accDataArray, startIndex, stopIndex, alarmLimitData );
					drawNewData = 0;
				}
			}

			gui_status_t
		        clickStatus = GuiDriver_QueueMsgGet( &fallData_packet , OSA_WAIT_FOREVER );

	        if( GUI_STATUS_SUCCESS == clickStatus )
	        {
	            if( packetType_pressUp == fallData_packet.type )
	            {
	            	if( flashMeasDataViewAddress < flashMeasDataAddress - 0x100 )
	            	{
	            		flashMeasDataViewAddress += 0x100;
	            	}
	            	else
	            	{
	            		flashMeasDataViewAddress = EXT_FLASH_MEAS_DATA_ADDRESS;
	            	}
	            }

	            if( packetType_pressDown == fallData_packet.type )
	            {
	            	if( flashMeasDataViewAddress > EXT_FLASH_MEAS_DATA_ADDRESS )
					{
						flashMeasDataViewAddress -= 0x100;
					}
	            	else
	            	{
						flashMeasDataViewAddress = flashMeasDataAddress - 0x100;
	            	}
	            }

	            if( packetType_pressRight == fallData_packet.type )
	            {
	            	if( viewPosition < 3 )
	            	{
	            		viewPosition ++;
	            	}
	            	else
	            	{
	            		viewPosition = 1;
	            	}
	            }
				drawNewData = 1;
	        }
	   }
}


static void fallData_Header( uint8_t accMaxData, uint8_t accAvgData, uint8_t alarmLimitData,
				uint16_t alarmSumLimitData, uint16_t alarmSumData, uint8_t minPollDelayData )
{
	fallData_charOut.dynamicArea.xCrd = 2;
	fallData_charOut.dynamicArea.yCrd = 21;
	fallData_charOut.textProperties.alignParam = OLED_TEXT_ALIGN_LEFT;
	fallData_charOut.textProperties.fontColor = GUI_COLOR_GREEN;
	GuiDriver_LabelSetCaption( &fallData_charOut, (uint8_t*)"Avg" );
	GuiDriver_LabelDraw( &fallData_charOut );

	fallData_charOut.dynamicArea.yCrd = 47;
	GuiDriver_LabelSetCaption( &fallData_charOut, (uint8_t*)"PollR" );
	GuiDriver_LabelDraw( &fallData_charOut );

	fallData_charOut.dynamicArea.yCrd = 34;
	fallData_charOut.textProperties.fontColor = GUI_COLOR_WHITE;
	snprintf( (char*)fallData_charOut.caption, 7, "%i.%01i", accAvgData / 10, accAvgData % 10 );
	GuiDriver_LabelDraw( &fallData_charOut );

	fallData_charOut.dynamicArea.yCrd = 60;
	snprintf( (char*)fallData_charOut.caption, 7, "%d ms" , minPollDelayData );
	GuiDriver_LabelDraw( &fallData_charOut );

	fallData_charOut.dynamicArea.xCrd = 32;
    fallData_charOut.dynamicArea.yCrd = 21;
    fallData_charOut.textProperties.alignParam = OLED_TEXT_ALIGN_CENTER;
    fallData_charOut.textProperties.fontColor = GUI_COLOR_RED;
    GuiDriver_LabelSetCaption( &fallData_charOut, (uint8_t*)"Sum" );
    GuiDriver_LabelDraw( &fallData_charOut );

    fallData_charOut.dynamicArea.yCrd = 47;
    GuiDriver_LabelSetCaption( &fallData_charOut, (uint8_t*)"SLimit" );
    GuiDriver_LabelDraw( &fallData_charOut );

    fallData_charOut.dynamicArea.yCrd = 34;
    fallData_charOut.textProperties.fontColor = GUI_COLOR_WHITE;
    snprintf( (char*)fallData_charOut.caption, 8, "%i.%01i", alarmSumData / 10, alarmSumData % 10 );
    GuiDriver_LabelDraw( &fallData_charOut );

    fallData_charOut.dynamicArea.yCrd = 60;
	snprintf( (char*)fallData_charOut.caption, 8, "%d g", alarmSumLimitData / 10 );
    GuiDriver_LabelDraw( &fallData_charOut );

	fallData_charOut.dynamicArea.xCrd = 64;
	fallData_charOut.dynamicArea.yCrd = 21;
	fallData_charOut.textProperties.alignParam = OLED_TEXT_ALIGN_RIGHT;
	fallData_charOut.textProperties.fontColor = GUI_COLOR_BLUE_1;
	GuiDriver_LabelSetCaption( &fallData_charOut, (uint8_t*)"Max" );
	GuiDriver_LabelDraw( &fallData_charOut );

	fallData_charOut.dynamicArea.yCrd = 47;
	GuiDriver_LabelSetCaption( &fallData_charOut, (uint8_t*)"Limit" );
	GuiDriver_LabelDraw( &fallData_charOut );

	fallData_charOut.dynamicArea.yCrd = 34;
	fallData_charOut.textProperties.fontColor = GUI_COLOR_WHITE;
	snprintf( (char*)fallData_charOut.caption, 6, "%i.%01i", accMaxData / 10, accMaxData % 10 );
	GuiDriver_LabelDraw( &fallData_charOut );

	fallData_charOut.dynamicArea.yCrd = 60;
	snprintf( (char*)fallData_charOut.caption, 6, "%i.%01i g", alarmLimitData / 10, alarmLimitData % 10 );
	GuiDriver_LabelDraw( &fallData_charOut );
}



static void fallData_View(uint8_t viewPosition, uint8_t* ptr_startIndex, uint8_t* ptr_stopIndex)
{
	fallAssistant_pixel.dynamicArea.yCrd = 19 ;
	GuiDriver_ImageDraw( &screen_imgBackground );
	GuiDriver_ImageDraw( &screen_buttonNext );

	switch( viewPosition )
	{
		case 1:
		{
			*ptr_startIndex = 0;
			*ptr_stopIndex = 95;
			fallAssistant_pixel.img = orange_bmp;
    		fallAssistant_pixel.dynamicArea.xCrd = 9;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
    		fallAssistant_pixel.dynamicArea.xCrd = 14;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.img = red_bmp;
        	fallAssistant_pixel.dynamicArea.xCrd = 4;
	        GuiDriver_ImageDraw(&fallAssistant_pixel);
			break;
		}

		case 2:
		{
			*ptr_startIndex = 70;
			*ptr_stopIndex = 166;
			fallAssistant_pixel.img = orange_bmp;
			fallAssistant_pixel.dynamicArea.xCrd = 4;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.dynamicArea.xCrd = 14;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.img = red_bmp;
        	fallAssistant_pixel.dynamicArea.xCrd = 9;
	        GuiDriver_ImageDraw(&fallAssistant_pixel);
			break;
		}

		case 3:
		{
			*ptr_startIndex = 143;
			*ptr_stopIndex = 239;
			fallAssistant_pixel.img = orange_bmp;
			fallAssistant_pixel.dynamicArea.xCrd = 4;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.dynamicArea.xCrd = 9;
        	GuiDriver_ImageDraw(&fallAssistant_pixel);
        	fallAssistant_pixel.img = red_bmp;
        	fallAssistant_pixel.dynamicArea.xCrd = 14;
	        GuiDriver_ImageDraw(&fallAssistant_pixel);
			break;
		}
		default: {}
	}
}

static void fallData_DrawGraph( uint8_t accDataArray[], uint8_t startIndex, uint8_t stopIndex, uint8_t alarmLimitData )
{
	uint8_t graphOffsetY = 81;												// y-offset position of data graph on screen
	uint8_t graphPositionX = 0;

	for(uint8_t dataIndex = startIndex + 1; dataIndex < stopIndex; dataIndex++)
	{
		fallAssistant_pixel.dynamicArea.xCrd = graphPositionX;

		if( accDataArray[dataIndex] < alarmLimitData )					// if acceleration value is below threshold, line is blue else line is red
		{
				fallAssistant_pixel.img = bluedot_bmp;
		}
		else
		{
				fallAssistant_pixel.img = reddot_bmp;
		}

		if( accDataArray[dataIndex - 1] <= accDataArray[dataIndex])			// if data line rises up
		{
			for( uint8_t i = ( accDataArray[dataIndex - 1] ); i <= ( accDataArray[dataIndex] ); i ++ )
			{
				fallAssistant_pixel.dynamicArea.yCrd = ( graphOffsetY - i );
				GuiDriver_ImageDraw(&fallAssistant_pixel);
			}
		}
		else																// else data line falls down
		{
			for( uint8_t i = ( accDataArray[dataIndex - 1] ); i > ( accDataArray[dataIndex] ); i -- )
			{
				fallAssistant_pixel.dynamicArea.yCrd = ( graphOffsetY - i );
				GuiDriver_ImageDraw(&fallAssistant_pixel);
			}
		}
		if( graphPositionX < 95)
		{
			graphPositionX++;
		}
	}
}

static void fallData_ReadAlarmData( uint8_t accDataArray[], uint8_t* ptr_alarmDataNumber,
		uint8_t* ptr_accMaxData, uint8_t* ptr_accAvgData, uint8_t* ptr_alarmLimitData,
		uint16_t* ptr_alarmSumLimitData, uint16_t* ptr_alarmSumData, uint8_t* ptr_minPollDelayData )
{
		*ptr_alarmSumLimitData = 0;
		*ptr_alarmSumData = 0;

		uint8_t	accDataArrayIndex =- MEAS_DATA_HEADER_SIZE;

			*ptr_alarmDataNumber = accDataArray[accDataArrayIndex++];							// alarm counter value
			data_time.hour = accDataArray[accDataArrayIndex++];								// 6 bytes of time stamp
			data_time.minute= accDataArray[accDataArrayIndex++];
			data_time.second = accDataArray[accDataArrayIndex++];
			data_time.day = accDataArray[accDataArrayIndex++];
			data_time.month = accDataArray[accDataArrayIndex++];
			data_time.year = accDataArray[accDataArrayIndex++];
			*ptr_accMaxData = accDataArray[accDataArrayIndex++];							// maximal alarm value
			*ptr_accAvgData = accDataArray[accDataArrayIndex++];							// average alarm value
			*ptr_alarmLimitData = accDataArray[accDataArrayIndex++];							// alarm limit value
			accDataArrayIndex ++;
			*ptr_alarmSumLimitData |= accDataArray[accDataArrayIndex--] << 8;					// high byte alarm sum limit value
			*ptr_alarmSumLimitData |= accDataArray[accDataArrayIndex++];						// low byte alarm sum limit value
			accDataArrayIndex += 2;
			*ptr_alarmSumData |= accDataArray[accDataArrayIndex--] << 8;						// high byte of alarm sum value
			*ptr_alarmSumData |= accDataArray[accDataArrayIndex++];								// low byte of alarm sum value
			accDataArrayIndex ++;
			*ptr_minPollDelayData = accDataArray[accDataArrayIndex];
}

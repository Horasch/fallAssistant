/*
 * fallData_objects.c
 *
 *  Created on: 02.09.2016
 *      Author: Juri
 */


#include "screens_common.h"
#include "fallData_private.h"
#include "fallData.h"

/**
 * ***********************************************************************************
* Definition of fallData main screen
 * ***********************************************************************************
 * */

static guiScreen_t
	fallData_mainScreen;

guiScreen_t
	fallData_coverScreen =
	{
		.navigation =
		{
			.up     = &fallConfig_coverScreen,
			.down   = &gui_weatherStation_coverScreen,
			.left   = &appsScreen,
			.right  = &fallData_mainScreen
		},

		.image = blank_cover_bmp,

		.initFunction        = fallData_Cover_Init,
		.createTaskFunction  = NULL,
		.destroyTaskFunction = NULL
	};

static guiScreen_t
    fallData_mainScreen =
    {
        .navigation =
        {
            .up     = NULL,
            .down   = NULL,
            .left   = &fallData_coverScreen,
            .right  = NULL
        },

        .image = blank_screen_bmp,

        .initFunction        = fallData_Init,
        .createTaskFunction  = fallData_CreateTasks,
        .destroyTaskFunction = fallData_DestroyTasks
    };


/** labels */

guiLabel_t fallData_alarm_label =
{
    .dynamicArea =
    {
		.xCrd   = 23,
		.yCrd   = 42,
        .width  = 50,
        .height = 28
    },
    .textProperties =
    {
        .font       = guiFont_Tahoma_16_Regular,
        .fontColor  = GUI_COLOR_ORANGE,
        .alignParam = OLED_TEXT_ALIGN_CENTER,
        .background = blank_screen_bmp
    },
    .caption = NULL,
    .captionLength = 6
};

guiLabel_t fallData_charOut =
{
    .dynamicArea =
    {
        .xCrd   = 3,
        .yCrd   = 62,
        .width  = 30,
        .height = 13
    },

    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_WHITE,
        .alignParam = OLED_TEXT_ALIGN_LEFT,
        .background = blank_screen_bmp
    },

    .caption = NULL,
    .captionLength = 6
};


/*
 * ambilight_private.h
 *
 *  Created on: 16.07.2016
 *      Author: Juri
 */

#pragma once

#include <stdint.h>
#include "gui_driver.h"



// Resources
extern const uint8_t ambilight_icon_000_bmp[5006];
extern const uint8_t ambilight_icon_125_bmp[5006];
extern const uint8_t ambilight_icon_250_bmp[5006];
extern const uint8_t ambilight_icon_375_bmp[5006];
extern const uint8_t ambilight_icon_500_bmp[5006];
extern const uint8_t ambilight_icon_625_bmp[5006];
extern const uint8_t ambilight_icon_750_bmp[5006];
extern const uint8_t ambilight_icon_875_bmp[5006];
extern const uint8_t ambilight_icon_1000_bmp[5006];


// Objects
extern guiLabel_t ambilight_labelValue;




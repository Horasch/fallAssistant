/*
 * ambilight.h
 *
 *  Created on: 16.07.2016
 *      Author: Juri
 */

#pragma once

#include "gui_driver.h"

#define AMBILIGHT_STACK_SIZE ( 0x500 )
#define AMBILIGHT_PRIO       ( HEXIWEAR_GUI_PRIO )

// screens
extern guiScreen_t ambilight_coverScreen;

// Callbacks
void ambilight_Init( void *param );
void ambilight_Cover_Init( void *param );
void ambilight_CreateTasks(void *param);
void ambilight_DestroyTasks(void *param);

void ambilight_UpdateBrightnessLevel(uint8_t level);

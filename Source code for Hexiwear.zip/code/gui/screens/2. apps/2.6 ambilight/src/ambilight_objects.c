/*
 * ambilight objects.h
 *
 *  Created on: 09.07.2016
 *      Author: Juri
 */

#include "screens_common.h"
#include "ambilight_private.h"
#include "ambilight.h"

guiScreen_t ambilight_mainScreen;

guiScreen_t
	ambilight_coverScreen =
    {
        .navigation =
        {
            .up     = &flashlightScreen,
            .down   = &fallAssistant_coverScreen,
            .left   = &appsScreen,
            .right  = &ambilight_mainScreen
        },

        .image = blank_cover_bmp,

        .initFunction        = ambilight_Cover_Init,
        .createTaskFunction  = NULL,
        .destroyTaskFunction = NULL
    };

guiScreen_t ambilight_mainScreen =
    {
        .navigation =
        {
            .up     = NULL,
            .down   = NULL,
            .left   = &ambilight_coverScreen,
            .right  = NULL
        },

        .image = blank_screen_bmp,

        .initFunction        = ambilight_Init,
        .createTaskFunction  = ambilight_CreateTasks,
        .destroyTaskFunction = ambilight_DestroyTasks
    };

/** labels */

guiLabel_t ambilight_labelValue =
{
    .dynamicArea =
    {
    .xCrd   = 53,
    .yCrd   = 79,
    .width  = 43,
    .height = 15
    },

    .textProperties =
    {
    .font       = guiFont_Tahoma_8_Regular,
    .fontColor  = GUI_COLOR_BLUE,
    .alignParam = OLED_TEXT_ALIGN_LEFT,
    .background = blank_screen_bmp
    },

    .caption       = NULL,
    .captionLength = 6
};

/*
 * ambilight_driver.h
 *
 *  Created on: 16.07.2016
 *      Author: Juri
 */

/** includes */

#include "gui_driver.h"
#include "ambilight_private.h"
#include "ambilight.h"
#include "screens_common.h"
#include "TSL_driver.h"
#include "OLED_driver.h"


/** private variables */

static uint8_t ambilight_level;

static hostInterface_packet_t ambilight_dataPacket;

static task_handler_t ambilight_taskHandler;

/** private function declarations */

static void ambilight_UpdateAmbilightLevel(uint8_t level);
static void ambilight_AppTask(task_param_t param);

/**
 * initialize the ambilight cover screen
 * @param param optional parameter
 */
void ambilight_Cover_Init( void *param )
{
	screen_imgIcon.img = ambilight_icon_1000_bmp;
	GuiDriver_ImageAddToScr( &screen_imgIcon );
   	GuiDriver_ImageAddToScr( &screen_buttonOnOff );

    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Ambilight" );
    GuiDriver_LabelDraw( &screen_label );
}

/**
 * initialize the ambilight screen
 * @param param optional parameter
 */
void ambilight_Init( void *param )
{
		GuiDriver_LabelCreate( &screen_label );
		GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Ambilight" );
		GuiDriver_LabelDraw( &screen_label );

		screen_imgIcon.img = ambilight_icon_000_bmp;
		GuiDriver_ImageAddToScr( &screen_imgIcon );

		GuiDriver_LabelCreate( &ambilight_labelValue );
		TSL_Enable ();

  // Register for packets we want to receive

	if ( false == gui_sensorTag_IsActive() )
	{
		GuiDriver_RegisterMinPollDelay( 100 );
		GuiDriver_RegisterForSensors( PACKET_LUX, 100, true );
	}

	else
	{
		GuiDriver_RegisterForSensors( PACKET_LUX,  -1, true );
	}
}

/**
 * create tasks in the ambilight screen app
 * @param param optional parameter
 */
void ambilight_CreateTasks( void *param )
{
  osa_status_t
  	  taskStatus = OSA_TaskCreate (
  			  	  	  	  	  	  	ambilight_AppTask,
									(uint8_t *) "ambilight app",
									AMBILIGHT_STACK_SIZE,
									NULL,
									AMBILIGHT_PRIO,
									(task_param_t)0,
									false,
									&ambilight_taskHandler
  	  	  	  	  	  	  	  );

  if ( kStatus_OSA_Success != taskStatus )
  {
    catch( CATCH_INIT );
  }
}

/**
 * destroy current running tasks in the ambilight screen app
 * @param param optional parameter
 */
void ambilight_DestroyTasks( void *param )
{

  OSA_TaskDestroy( ambilight_taskHandler );

  GuiDriver_UnregisterFromSensors( PACKET_LUX, false );

  OLED_DestroyDynamicArea();
  GuiDriver_LabelDestroy( &screen_label );
  GuiDriver_LabelDestroy( &ambilight_labelValue );

  TSL_Disable();

  power_EnablePowerSave();

}


/**
 * wait for packets and analyze data
 * @param param optional parameter
 */
static void ambilight_AppTask(task_param_t param)
{


	while(1)
	{
	  power_DisablePowerSave();

  	gui_status_t
          clickStatus = GuiDriver_QueueMsgGet( &ambilight_dataPacket , OSA_WAIT_FOREVER );

    if( GUI_STATUS_SUCCESS == clickStatus )
    {
        if(
                ( packetType_ambiLight   != ambilight_dataPacket.type )
          )
        {
            continue;
        }
    }

    // Extract data
	  mE_t sensorValue = (mE_t)( ambilight_dataPacket.data[0] | (mE_t)ambilight_dataPacket.data[1] << 8 );

	  switch (ambilight_dataPacket.type)
	  {
      	  // Ambilight Service
	  	  case packetType_ambiLight:
	  	  {

	  		  ambilight_level = (uint8_t)sensorValue;
	  		  break;

	  	  }
	  	  default: {}

	  }

	  ambilight_UpdateAmbilightLevel(ambilight_level);
	  ambilight_UpdateBrightnessLevel(ambilight_level);

	  snprintf( (char*)ambilight_labelValue.caption, 6, "%d %%", (uint8_t)sensorValue );
	  GuiDriver_LabelDraw(&ambilight_labelValue);
	}

}

/**
 * update the ambilight level on GUI
 * @param level ambilight level in percents
 */
static void ambilight_UpdateAmbilightLevel(uint8_t level)
{
	const uint8_t *img;

  if ( level >= 98 )
  {
		img = ambilight_icon_1000_bmp;
  }
  else if ( level >= 88 )
  {
		img = ambilight_icon_875_bmp;
  }
  else if ( level >= 75 )
  {
		img = ambilight_icon_750_bmp;
  }
  else if ( level >= 63 )
  {
		img = ambilight_icon_625_bmp;
  }
  else if ( level >= 50 )
  {
		img = ambilight_icon_500_bmp;
  }
  else if ( level >= 38 )
  {
		img = ambilight_icon_375_bmp;
  }
  else if ( level >= 25 )
  {
		img = ambilight_icon_250_bmp;
  }
  else if ( level >= 13 )
  {
		img = ambilight_icon_125_bmp;
  }
  else
  {
	    img = ambilight_icon_000_bmp;
  }

  if( screen_imgIcon.img != img )
  {
	  screen_imgIcon.img = img;
    GuiDriver_ImageDraw(&screen_imgIcon);
  }
}


void ambilight_UpdateBrightnessLevel(uint8_t level)
{
	  uint8_t brightness;
	  uint8_t brightness_backup = 0x1;

	  brightness = level/7;

	  if ( level >= 98 )
	  {
		  brightness = 0xF;
	  }

	  if( brightness_backup != brightness )
	  {
		  OLED_SendCmd( OLED_CMD_CONTRASTMASTER, FIRST_BYTE );
		  OLED_SendCmd( 0xC0 | (brightness), OTHER_BYTE );
		  brightness_backup = brightness;
	  }
}

/**
 * \file fallAssistant.h
 * \version 1.00
 * \Juri Kuebler
 * \08.2016
 */

#pragma once

#include "gui_driver.h"
#include "FLASH_driver.h"

#define FALL_ASSISTANT_STACK_SIZE			( 0x500 )
#define FALL_ASSISTANT_PRIO					( HEXIWEAR_GUI_PRIO )
#define EXT_FLASH_APP_CONFIG_ADDRESS		( 0xE0000 )
#define EXT_FLASH_MEAS_DATA_ADDRESS			( 0x10000 )
#define MEAS_DATA_HEADER_SIZE				( 15 )
#define ALARM_DATA_SIZE						( 10 )
#define ACC_DATA_SIZE						( 256 )
#define DISPLAY_TIMEOUT						( 21 )
#define GRAPH_Y_POSITION					( 81 )

extern guiScreen_t
	fallAssistant_coverScreen;

extern guiImage_t
    fallAssistant_pixel;

extern guiLabel_t
	fallAssistant_alarm_label,
	fallAssistant_charOut;

extern statusFLASH_t flashStatus;								// success flash flag
extern uint32_t flashMeasDataAddress;							// Value where the next measurement data can be stored
extern uint8_t alarmCounter;									// Value of registered alarms
extern uint8_t alarmLimit;										// Value of configured alarm threshold
extern uint16_t alarmSumLimit;									// Sum of alarm values in data frame
extern uint8_t minPollDelayValue;								// 2-3ms = 253Hz, 4-5ms = 168Hz, 6-7ms = 125Hz, 8-9ms = 100Hz, 10ms = 83Hz




void fallAssistant_Cover_Init();
void fallAssistant_Init();
void fallAssistant_CreateTasks();
void fallAssistant_DestroyTasks();

void fallAssistant_RegisterBLE();
void fallAssistant_UnregisterBLE();

void fallAssistant_ActiveMode( uint8_t* ptr_displayCountdown, uint8_t* ptr_activeMode );
void fallAssistant_ReadConfigData( 	uint32_t* ptr_flashMeasDataAddress,
									uint8_t* ptr_alarmCounter,
									uint8_t* ptr_alarmLimit,
									uint16_t* ptr_alarmSumLimit,
									uint8_t* ptr_minPollDelayValue );

void fallAssistant_SaveConfigData( 	uint32_t flashMeasDataAddress,
									uint8_t alarmCounter,
									uint8_t alarmLimit,
									uint16_t alarmSumLimit,
									uint8_t minPollDelayValue );

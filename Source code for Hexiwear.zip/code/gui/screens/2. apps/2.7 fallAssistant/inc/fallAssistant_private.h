/**
 * \file fallAssistant_private.h
 * \version 1.00
 * \Juri Kuebler
 * \08.2016
 */

#pragma once

#include "gui_driver.h"
#include <stdint.h>

extern const uint8_t
    fallAssistant_icon_bmp[ 5006 ],
	fallAssistant_icon_gray_bmp[ 5006 ],
	fallAssistant_icon_memory_full_bmp[ 5006 ];



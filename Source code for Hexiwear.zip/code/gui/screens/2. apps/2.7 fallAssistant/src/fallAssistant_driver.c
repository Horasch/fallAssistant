/**
 * \file fallAssistant_driver.c
 * \version 1.00
 * \Juri Kuebler
 * \08.2016
 */

#include "fsl_os_abstraction.h"
#include "OLED_driver.h"
#include "OLED_info.h"
#include "gui_sensorTag.h"
#include "fallAssistant.h"
#include "fallAssistant_private.h"
#include "screens_common.h"
#include "haptic.h"
#include "flashlight.h"
#include "FLASH_driver.h"
#include "ambilight_private.h"
#include "rtc_driver.h"
#include "power_driver.h"
#include "gui_driver.h"
#include "gui_types.h"
#include "sensor_driver.h"

/** private variables */

static task_handler_t
    fallAssistant_taskHandler;

static hostInterface_packet_t
        fallAssistant_packet;

static packet_pushTarget_t
    appBackupList[PACKET_ALL];

static packet_pushTarget_t
    appPushTarget = PACKET_PUSH_OLED;

static rtc_datetime_t
  alarm_time;

uint32_t flashMeasDataAddress = 0;							// Value where the next measurement data can be stored
uint8_t alarmCounter = 0;									// Value of registered alarms
uint8_t alarmLimit = 0;										// Value of configured alarm threshold
uint16_t alarmSumLimit = 0;									// Sum of alarm values in data frame
uint8_t minPollDelayValue = 2;								// 2-3ms = 253Hz, 4-5ms = 168Hz, 6-7ms = 125Hz, 8-9ms = 100Hz, 10ms = 83Hz
uint8_t activeMode = 1;										// variable for display activity and power save mode
uint8_t displayCountdown = 21;								// variable for display activity and power save mode


/** private declarations */

static void fallAssistant_AppTask();
static void fallAssistant_PowerSaveMode( uint8_t* ptr_activeMode );
static void fallAssistant_NewVector( mE_t sensorData[], uint8_t dataIndex, uint8_t accDataArray[],
		uint8_t alarmLimit, uint8_t* ptr_newAlarm, uint8_t* ptr_alarmIndex );
static void fallAssistant_AvgMaxSumCalc( uint8_t accDataArray[], uint16_t accDataSize, uint8_t alarmLimit, uint16_t alarmSumLimit,
		uint8_t* ptr_accAvgValue, uint8_t* ptr_accMaxValue, uint16_t* ptr_alarmSum, uint8_t* ptr_newSumAlarm, uint8_t* ptr_newAlarm );
static void fallAssistant_SendAlarm( uint8_t alarmCounter, uint8_t accMaxValue, uint8_t accAvgValue, uint8_t* ptr_alarmTransmitted );
static void fallAssistant_DrawGraph( uint8_t gfxCounter, uint8_t dataIndex, uint8_t accDataArray[], uint8_t alarmLimit );
static void fallAssistant_DeleteGraph( uint8_t gfxCounter, uint8_t dataIndex, uint8_t accDataArray[] );
static void fallAssistant_DrawMax( uint8_t accMaxValue );
static void fallAssistant_DrawAvg( uint8_t accAvgValue );
static void fallAssistant_DrawSum( uint16_t alarmSum );
static void fallAssistant_DrawOrientation( mE_t sensorData[], uint8_t* ptr_lastBarValue );
static void fallAssistant_AlarmReset( uint8_t* ptr_newAlarm, uint8_t* ptr_newSumAlarm, uint8_t* ptr_alarmCountdown, uint8_t* ptr_alarmTransmitted );
static void fallAssistant_SaveAlarmData( uint8_t accDataArray[], uint8_t* ptr_dataIndex, uint8_t alarmCounter,
			uint8_t accMaxValue, uint8_t accAvgValue, uint8_t alarmLimit, uint16_t alarmSumLimit, uint16_t alarmSum );
static void fallAssistant_Blink( bool blinkFlag );

/** public API */

void fallAssistant_ReadConfigData(	uint32_t* ptr_flashMeasDataAddress, uint8_t* ptr_alarmCounter, uint8_t* ptr_alarmLimit, uint16_t* ptr_alarmSumLimit,
									uint8_t* ptr_minPollDelayValue )
{
//** Restore App-Config-Data from the external Flash */

	uint8_t flashConfigData[9];

	while( STATUS_FLASH_SUCCESS != FLASH_ReadData( EXT_FLASH_APP_CONFIG_ADDRESS, flashConfigData, sizeof(flashConfigData) ) ) {};

	*ptr_flashMeasDataAddress |= flashConfigData[3] << 24;						// Address for APP-Measurement-Data
	*ptr_flashMeasDataAddress |= flashConfigData[2] << 16;
	*ptr_flashMeasDataAddress |= flashConfigData[1] << 8;
	*ptr_flashMeasDataAddress |= flashConfigData[0];
	*ptr_alarmCounter = flashConfigData[4];										// Value of registered alarms
	*ptr_alarmLimit = flashConfigData[5];										// Value of configured alarm threshold
	*ptr_alarmSumLimit |= flashConfigData[7] << 8;								// Value of configured alarm sum
	*ptr_alarmSumLimit |= flashConfigData[6];
	*ptr_minPollDelayValue = flashConfigData[8];									// Value of time between measures

}

void fallAssistant_SaveConfigData( 	uint32_t flashMeasDataAddress, uint8_t alarmCounter, uint8_t alarmLimit, uint16_t alarmSumLimit,
									uint8_t minPollDelayValue )
{
	//** Save App-Config-Data to the external Flash */
	uint8_t flashConfigData[9] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	flashConfigData[0] = flashMeasDataAddress;
	flashConfigData[1] = flashMeasDataAddress >> 8;
	flashConfigData[2] = flashMeasDataAddress >> 16;
	flashConfigData[3] = flashMeasDataAddress >> 24;
	flashConfigData[4] = alarmCounter;								// Save new value of alarm counter
	flashConfigData[5] = alarmLimit;
	flashConfigData[6] = alarmSumLimit;
	flashConfigData[7] = alarmSumLimit >> 8;
	flashConfigData[8] = minPollDelayValue;

	while( STATUS_FLASH_SUCCESS != FLASH_EraseSector( EXT_FLASH_APP_CONFIG_ADDRESS ) ) {};
	while( STATUS_FLASH_SUCCESS != FLASH_WriteData( EXT_FLASH_APP_CONFIG_ADDRESS, flashConfigData, sizeof(flashConfigData) ) ) {};

}

/**
 * initialize the fall assistant app
 * @param param optional parameter
 */
void fallAssistant_Cover_Init( void* param )
{
	screen_imgIcon.img = fallAssistant_icon_bmp;
	GuiDriver_ImageAddToScr( &screen_imgIcon );
   	GuiDriver_ImageAddToScr( &screen_buttonOk );

    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Fall Assistant" );
    GuiDriver_LabelDraw( &screen_label );
}

void fallAssistant_Init( void* param )
{
	screen_imgIcon.img = fallAssistant_icon_gray_bmp;
	GuiDriver_ImageAddToScr( &screen_imgIcon );

    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Fall Assistant" );
    GuiDriver_LabelDraw( &screen_label );

    GuiDriver_LabelCreate( &fallAssistant_alarm_label );
    GuiDriver_LabelCreate( &fallAssistant_charOut );
    GuiDriver_ImageDraw( &screen_buttonTouch );

    fallAssistant_ReadConfigData( &flashMeasDataAddress, &alarmCounter, &alarmLimit, &alarmSumLimit, &minPollDelayValue );

//* Set Sensor Parameters */
    fallAssistant_RegisterBLE();

	if ( false == gui_sensorTag_IsActive() )
	{
		GuiDriver_RegisterMinPollDelay( minPollDelayValue );					// 9ms = 100Hz
        GuiDriver_RegisterForSensors( PACKET_ACC, minPollDelayValue, true );	// 2-3ms = 253Hz, 4-5ms = 168Hz, 6-7ms = 125Hz, 8-9ms = 100Hz, 10ms = 83Hz

	}
	else
	{
		GuiDriver_RegisterForSensors( PACKET_ACC, -1, true );
	}

	GuiDriver_RegisterForNavigation( GUI_NAVIGATION_UP );
    GuiDriver_RegisterForNavigation( GUI_NAVIGATION_DOWN );
    GuiDriver_RegisterForNavigation( GUI_NAVIGATION_RIGHT );

    HEXIWEAR_SetBackupList( (packet_pushTarget_t*)appBackupList );
    HEXIWEAR_SetTargetApp ( appPushTarget );

	power_DisablePowerSave();
}

/**
 * create the app main task
 * @param param optional parameter
 */
void fallAssistant_CreateTasks( void* param )
{
    osa_status_t
        taskStatus = OSA_TaskCreate(
                                        fallAssistant_AppTask,
                                        (uint8_t*) "fall assistant",
                                        FALL_ASSISTANT_STACK_SIZE,
                                        NULL,
                                        FALL_ASSISTANT_PRIO,
                                        (task_param_t)0,
                                        false,
                                        &fallAssistant_taskHandler
                                    );

    if ( kStatus_OSA_Success != taskStatus )
    {
        catch( CATCH_INIT );
    }
}

/**
 * destroy the app task
 * @param param optional parameter
 */
void fallAssistant_DestroyTasks( void* param )
{
    fallAssistant_SaveConfigData( flashMeasDataAddress, alarmCounter, alarmLimit, alarmSumLimit, minPollDelayValue );

    OSA_TaskDestroy( fallAssistant_taskHandler );

    fallAssistant_UnregisterBLE();
    GuiDriver_UnregisterFromSensors( PACKET_ACC, true );

    OLED_DestroyDynamicArea();

    GuiDriver_LabelDestroy( &screen_label );
    GuiDriver_LabelDestroy( &fallAssistant_alarm_label );
    GuiDriver_LabelDestroy( &fallAssistant_charOut );

    GuiDriver_UnregisterFromNavigation( GUI_NAVIGATION_UP );
    GuiDriver_UnregisterFromNavigation( GUI_NAVIGATION_DOWN );
    GuiDriver_UnregisterFromNavigation( GUI_NAVIGATION_RIGHT );

    HEXIWEAR_SetBackupList( NULL );
    HEXIWEAR_SetTargetApp ( PACKET_PUSH_NONE );

	fallAssistant_ActiveMode( &displayCountdown, &activeMode );
    power_EnablePowerSave();
}

/** private API */

/**
 * fall assistant main task, charged with
 * getting data from sensors and displaying them
 */
static void fallAssistant_AppTask()
{
	bool blink = 1;										// variable for app-live-symbol
	uint8_t alarmTransmitted = 0;						// variable for alarm transmission over BLE
	uint8_t newAlarm = 0;								// Set flag for new alarm
	uint8_t newSumAlarm = 0;							// Set flag for new sum alarm
	uint8_t gfxCounter = 0;								// Counter variable for OLED-Display x-coordinate
//	uint8_t arrayCounter = 0;							// Counter for delay measurements
	mE_t sensorData[3] = {0};							// Array for measured ACC-Sensor-Data (x, y, z)
	uint8_t lastBarValue = 22;							// Value for the last bar graph position
	mE_t savePosition = 0;								// Value for save position recognition
	uint8_t dataIndex = 0;								// Array index for measurement data
	uint8_t alarmIndex = 0;								// Array index for alarm position
	uint8_t alarmIndexOffset = 20;						// Value for offset from alarm value index
	uint8_t alarmCountdown = 10;						// Counter value until phone alarm is triggered
	uint16_t alarmSum = 0;								// Value for sum of alarm values
	uint8_t accMaxValue = 0;							// Value of maximal acceleration in data frame
	uint8_t accAvgValue = 9;							// Value of average acceleration in data frame

	uint16_t accDataSize = 256;							// Number of measured data points
	uint8_t accDataArray[256];							// Array for measurement data

	uint8_t init = 0;									// Initialization counter for accData array
	do
	{
		accDataArray[init] = accAvgValue;				// Initialization of accData array with average values
		init++;
	} while (init);

    OLED_DrawBox ( 21, 16, 31, 2, 0xFFFF );
    OLED_DrawBox ( 53, 16, 22, 2, 0x211C );

	while (1)
    {
		gui_status_t
	        clickStatus = GuiDriver_QueueMsgGet( &fallAssistant_packet , OSA_WAIT_FOREVER );

        if( GUI_STATUS_SUCCESS == clickStatus )
        {
        	if ( packetType_accel == fallAssistant_packet.type )		// get new sensor values
        	{

        	mE_t
                sensorValue = (mE_t)( fallAssistant_packet.data[0] | (mE_t)fallAssistant_packet.data[1] << 8 );
        		sensorData[0] = sensorValue;
        	    sensorValue = (mE_t)( fallAssistant_packet.data[2] | (mE_t)fallAssistant_packet.data[3] << 8 );
        	    sensorData[1] = sensorValue;
   	        	sensorValue = (mE_t)( fallAssistant_packet.data[4] | (mE_t)fallAssistant_packet.data[5] << 8 );
   	        	sensorData[2] = sensorValue;
        	}

            if( packetType_pressUp == fallAssistant_packet.type )
            {
            	fallAssistant_ActiveMode( &displayCountdown, &activeMode );
            }

            if( packetType_pressDown == fallAssistant_packet.type )
            {
            	fallAssistant_ActiveMode( &displayCountdown, &activeMode );
            }

            if( packetType_pressRight == fallAssistant_packet.type )
            {
            	fallAssistant_ActiveMode( &displayCountdown, &activeMode );

            	if( newSumAlarm )
            	{
            		fallAssistant_AlarmReset( &newAlarm, &newSumAlarm, &alarmCountdown, &alarmTransmitted);
            	}
            }


            if( !newSumAlarm )
            {
        		if( !activeMode )
        		{
        			GREEN_LED_OFF();
        		}
        		else
        		{
        			BLUE_LED_OFF();
        		}

    			if( activeMode )
    			{
    				fallAssistant_DeleteGraph( gfxCounter, dataIndex, accDataArray );
    			}

    			fallAssistant_NewVector( sensorData, dataIndex, accDataArray, alarmLimit, &newAlarm, &alarmIndex );

    			if( activeMode )
    			{
    				fallAssistant_DrawGraph( gfxCounter, dataIndex, accDataArray, alarmLimit );
    			}

            	dataIndex++;
                gfxCounter++ ;

                if ( gfxCounter == ( OLED_SCREEN_WIDTH ) )													// start new gfxCounter
                {
                	gfxCounter = 0 ;
                }

            }

        	if( activeMode )
        	{
        		fallAssistant_DrawOrientation( sensorData, &lastBarValue );
           	}

        	if( displayCountdown == 1)
        	{
        		fallAssistant_PowerSaveMode( &activeMode );
        	}

        	if( !dataIndex )
        	{
            	blink = !blink ;

            	if ( activeMode )
            	{
            		fallAssistant_Blink( blink );
            	}

            	if( blink )
            	{
            		if( !activeMode )
            		{
            			GREEN_LED_ON();
            		}
            		else
            		{
            			BLUE_LED_ON();
            		}
            	}

            	if( displayCountdown )
            	{
            		displayCountdown--;
            	}

//            	arrayCounter++;
//            	snprintf( (char*)fallAssistant_alarm_label.caption, 6, "%d", arrayCounter );
//            	GuiDriver_LabelDraw( &fallAssistant_alarm_label );
        	}

            if ( newAlarm && dataIndex == ( alarmIndex - alarmIndexOffset ))
            {
            	fallAssistant_ActiveMode( &displayCountdown, &activeMode );
				screen_imgIcon.img = fallAssistant_icon_bmp;
				GuiDriver_ImageDraw( &screen_imgIcon );
            	fallAssistant_AvgMaxSumCalc
					( accDataArray, accDataSize, alarmLimit, alarmSumLimit, &accAvgValue, &accMaxValue, &alarmSum, &newSumAlarm, &newAlarm );
            }

            if( newSumAlarm )
            {
            	fallAssistant_ActiveMode( &displayCountdown, &activeMode );

            	if( alarmCountdown )
            	{
					if( alarmCountdown == 10 )
					{
						alarmCounter++;															// increase alarm counter
						fallAssistant_SaveAlarmData( accDataArray, &dataIndex, alarmCounter, accMaxValue, accAvgValue, alarmLimit, alarmSumLimit, alarmSum );
						GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Fall Assistant" );
						GuiDriver_LabelDraw( &screen_label );
						screen_imgIcon.img = fallAssistant_icon_gray_bmp;
						GuiDriver_ImageDraw( &screen_imgIcon );
						snprintf( (char*)fallAssistant_alarm_label.caption, 6, "%d", alarmCounter );
						GuiDriver_LabelDraw( &fallAssistant_alarm_label );
						haptic_Run();														// haptic run duration 40ms
						OSA_TimeDelay(960);													// 1000 - haptic run duration
						savePosition += sensorData[0];
						alarmCountdown--;
					}
					else if( alarmCountdown < 10 )
					{
						screen_imgIcon.img = fallAssistant_icon_bmp;
						GuiDriver_ImageDraw( &screen_imgIcon );
						haptic_Run();
						OSA_TimeDelay(260);
						screen_imgIcon.img = fallAssistant_icon_gray_bmp;
						GuiDriver_ImageDraw( &screen_imgIcon );
						snprintf( (char*)fallAssistant_alarm_label.caption, 6, "%d", alarmCountdown );
						GuiDriver_LabelDraw( &fallAssistant_alarm_label );
						haptic_Run();
						OSA_TimeDelay(660);
						savePosition += sensorData[0];
						alarmCountdown--;
					}
            	}
				if( !alarmCountdown )
				{
					fallAssistant_DrawMax( accMaxValue );
					fallAssistant_DrawAvg( accAvgValue );
					fallAssistant_DrawSum( alarmSum );
					FLASH_SetON();
					haptic_Run();
					FLASH_SetOFF();
					OSA_TimeDelay(460);
					savePosition /= 10;
					if( ( savePosition < -60 ) && ( savePosition > -100 ) )
					{
						fallAssistant_AlarmReset( &newAlarm, &newSumAlarm, &alarmCountdown, &alarmTransmitted);
					}
					if( !alarmTransmitted && newSumAlarm )
					{
						fallAssistant_SendAlarm( alarmCounter, accMaxValue, accAvgValue, &alarmTransmitted );
					}
				}
            }
        }
    }
}


void fallAssistant_RegisterBLE()				// Settings needed for Bluetooth communication, include Acceleration and Battery values
{
	GuiDriver_NotifyKW40( GUI_CURRENT_APP_SENSOR_TAG );
    sensor_RegisterPacketDelay( PACKET_BAT, 0 );
	sensor_SetPacketTargets( PACKET_ACC, sensor_GetPacketTargets( PACKET_ACC ) | PACKET_PUSH_KW40, false );
	sensor_SetPacketTargets( PACKET_BAT, sensor_GetPacketTargets( PACKET_BAT ) | PACKET_PUSH_KW40, true );
}

void fallAssistant_UnregisterBLE()				// Restore standard values after leaving the app
{
    sensor_SetPacketTargets( PACKET_BAT, sensor_GetPacketTargets( PACKET_BAT ) & ~PACKET_PUSH_KW40, true );
    sensor_SetPacketTargets( PACKET_ACC, sensor_GetPacketTargets( PACKET_ACC ) & ~PACKET_PUSH_KW40, true );
    sensor_ResetTargetsForKW40();
    GuiDriver_NotifyKW40( GUI_CURRENT_APP_IDLE );
}

static void fallAssistant_SendAlarm( uint8_t alarmCounter, uint8_t accMaxValue, uint8_t accAvgValue, uint8_t* ptr_alarmTransmitted )
{
	static hostInterface_packet_t
	  dataPacket;

	linkState_t
	  currentState = watch_CurrentLinkStateGet();

	uint8_t dataIndex = 0;

	if ( linkState_connected == currentState )
	{
		osa_status_t
			txStatus = kStatus_OSA_Success;

		dataPacket.length  = ALARM_DATA_SIZE;
		dataPacket.type    = packetType_alertOut;

		RTC_GetCurrentTime(&alarm_time);

		dataPacket.data[dataIndex++] = alarmCounter;						// alarm counter value
		dataPacket.data[dataIndex++] = alarm_time.hour;						// 6 bytes of time stamp
		dataPacket.data[dataIndex++] = alarm_time.minute;
		dataPacket.data[dataIndex++] = alarm_time.second;
		dataPacket.data[dataIndex++] = alarm_time.day;
		dataPacket.data[dataIndex++] = alarm_time.month;
		alarm_time.year = ( alarm_time.year - 2000 );
		dataPacket.data[dataIndex++] = alarm_time.year;
		dataPacket.data[dataIndex++] = accMaxValue;							// maximal alarm value
		dataPacket.data[dataIndex++] = accAvgValue;							// average alarm value
		dataPacket.data[dataIndex++] = minPollDelayValue;
		dataPacket.data[dataPacket.length] = gHostInterface_trailerByte;

		while( HostInterface_TxQueueMsgPut((hostInterface_packet_t *)&dataPacket, false) != kStatus_OSA_Success ) {}
	}
	*ptr_alarmTransmitted = 1;
}

void fallAssistant_ActiveMode( uint8_t* ptr_displayCountdown, uint8_t* ptr_activeMode )
{
//	while ( OLED_STATUS_SUCCESS != OLED_SendCmd( OLED_CMD_FUNCTIONSELECT, FIRST_BYTE ) ){}
	GPIO_DRV_SetPinOutput( PWR_OLED );
	OSA_TimeDelay( 50 );
	while ( OLED_STATUS_SUCCESS != OLED_SendCmd( OLED_CMD_DISPLAYON, FIRST_BYTE ) ) {}
	*ptr_displayCountdown = DISPLAY_TIMEOUT;
	*ptr_activeMode = 1;
}

static void fallAssistant_PowerSaveMode(uint8_t* ptr_activeMode)
{
	*ptr_activeMode = 0;
	while ( OLED_STATUS_SUCCESS != OLED_SendCmd( OLED_CMD_DISPLAYOFF, FIRST_BYTE ) ){}
	GPIO_DRV_ClearPinOutput( PWR_OLED );
//	OSA_TimeDelay( 100 );
//	while ( OLED_STATUS_SUCCESS != OLED_SendCmd( OLED_CMD_FUNCTIONSELECT, OTHER_BYTE ) ){}
}

static void fallAssistant_AlarmReset( uint8_t* ptr_newAlarm, uint8_t* ptr_newSumAlarm, uint8_t* ptr_alarmCountdown, uint8_t* ptr_alarmTransmitted)
{
	*ptr_newAlarm = 0;
	*ptr_newSumAlarm = 0;
	*ptr_alarmCountdown = 10;
	FLASH_SetOFF();
	screen_imgIcon.img = fallAssistant_icon_gray_bmp;
	GuiDriver_ImageDraw( &screen_imgIcon );
	*ptr_alarmTransmitted = 0;
}



static void fallAssistant_DrawOrientation( mE_t sensorData[], uint8_t* ptr_lastBarValue )		// draws the orientation bar
{
	uint8_t offsetX = 22;							// left border where bar graph begins
	uint8_t drawX = 0;								// X coordinate value for new pixel
	uint8_t positionLimit = 30;						// limit value for position 0.6g / 2

	/** set y-coordinate of bargraph */
		fallAssistant_pixel.dynamicArea.yCrd = 17;

		if( sensorData[0] <= 0 && sensorData[0] > -100 )
		{
			drawX = abs(sensorData[0]) / 2 + offsetX;

			/** delete old data point from screen */
			if( drawX <= *ptr_lastBarValue)
			{
				fallAssistant_pixel.img = black_bmp;
				for( uint8_t i = drawX; i < *ptr_lastBarValue; i++)
				{
					fallAssistant_pixel.dynamicArea.xCrd = i;
					GuiDriver_ImageDraw(&fallAssistant_pixel);
				}
			}

			/** draw new point on bar graph */
			for( uint8_t i = *ptr_lastBarValue; i < drawX; i++)
			{
				if( i >= ( positionLimit + offsetX ) )
				{
					fallAssistant_pixel.img = green_bmp;
				}
				else
				{
					fallAssistant_pixel.img = red_bmp;
				}
			fallAssistant_pixel.dynamicArea.xCrd = i;
			GuiDriver_ImageDraw(&fallAssistant_pixel);
			}

			*ptr_lastBarValue = drawX;
		}
}

static void fallAssistant_SaveAlarmData( uint8_t accDataArray[], uint8_t* ptr_dataIndex, uint8_t alarmCounter,
		uint8_t accMaxValue, uint8_t accAvgValue, uint8_t alarmLimit, uint16_t alarmSumLimit, uint16_t alarmSum  )
{
		uint8_t dataHeaderSize = MEAS_DATA_HEADER_SIZE;
		uint8_t accDataIndex = *ptr_dataIndex;
		uint8_t flashPageIndex = 0;
		uint8_t flashPage[256];								// Array for flash memory data

		do
		{
			flashPage[flashPageIndex] = accDataArray[accDataIndex];
			flashPageIndex++;
			accDataIndex++;
		}
		while( flashPageIndex);

		RTC_GetCurrentTime(&alarm_time);
		flashPageIndex =- dataHeaderSize;

		flashPage[flashPageIndex++] = alarmCounter;							// alarm counter value
		flashPage[flashPageIndex++] = alarm_time.hour;						// 6 bytes of time stamp
		flashPage[flashPageIndex++] = alarm_time.minute;
		flashPage[flashPageIndex++] = alarm_time.second;
		flashPage[flashPageIndex++] = alarm_time.day;
		flashPage[flashPageIndex++] = alarm_time.month;
		alarm_time.year = ( alarm_time.year - 2000 );
		flashPage[flashPageIndex++] = alarm_time.year;
		flashPage[flashPageIndex++] = accMaxValue;							// maximal alarm value
		flashPage[flashPageIndex++] = accAvgValue;							// average alarm value
		flashPage[flashPageIndex++] = alarmLimit;							// alarm limit value
	    flashPage[flashPageIndex++] = alarmSumLimit;						// low byte alarm sum limit value
	    flashPage[flashPageIndex++] = alarmSumLimit >> 8;					// high byte alarm sum limit value
		flashPage[flashPageIndex++] = alarmSum;								// low byte of alarm sum value
		flashPage[flashPageIndex++] = alarmSum >> 8;						// high byte of alarm sum value
		flashPage[flashPageIndex] = minPollDelayValue;

		while( STATUS_FLASH_SUCCESS != FLASH_WriteData( flashMeasDataAddress, flashPage, sizeof(flashPage) ) ) {};

		if( flashMeasDataAddress < 0x1FF00)								// end of meas data flash sector
		{
			flashMeasDataAddress += 0x100;
		}

		else
		{
			GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Memory Full" );
			GuiDriver_LabelDraw( &screen_label );
			screen_imgIcon.img = fallAssistant_icon_memory_full_bmp;
			GuiDriver_ImageAddToScr( &screen_imgIcon );
			flashMeasDataAddress = EXT_FLASH_MEAS_DATA_ADDRESS;
		}
}

static void fallAssistant_AvgMaxSumCalc(uint8_t accDataArray[], uint16_t accDataSize, uint8_t alarmLimit, uint16_t alarmSumLimit,
			uint8_t* ptr_accAvgValue, uint8_t* ptr_accMaxValue, uint16_t* ptr_alarmSum, uint8_t* ptr_newSumAlarm, uint8_t* ptr_newAlarm )
{
	*ptr_alarmSum = 0;
	*ptr_accAvgValue = 0;
	*ptr_accMaxValue = 10;
	uint8_t alarmLimitCounter = 0;

	for(uint16_t i = 0; i < accDataSize; i++)
	{
		if( alarmLimit < accDataArray[i])
		{
			*ptr_alarmSum += accDataArray[i];
			alarmLimitCounter++;
		}

		if( *ptr_accMaxValue < accDataArray[i])
		{
			*ptr_accMaxValue = accDataArray[i];
		}
	}

	*ptr_accAvgValue = (uint8_t)( *ptr_alarmSum / alarmLimitCounter );

	if( alarmSumLimit < *ptr_alarmSum )							// sets new sum alarm
	{
		*ptr_newSumAlarm = 1;
	}
	else
	{
		*ptr_newAlarm = 0;										// reset alarm & countdown value

		GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Fall Assistant" );
		GuiDriver_LabelDraw( &screen_label );
		screen_imgIcon.img = fallAssistant_icon_gray_bmp;
		GuiDriver_ImageDraw( &screen_imgIcon );
	}

}

static void fallAssistant_NewVector( mE_t sensorData[], uint8_t dataIndex, uint8_t accDataArray[],
		uint8_t alarmLimit, uint8_t* ptr_newAlarm, uint8_t* ptr_alarmIndex )
{
/** calculate absolute acceleration vector */
	uint16_t directionVector = sqrt(sensorData[0]*sensorData[0] + sensorData[1]*sensorData[1] + sensorData[2]*sensorData[2]);

/** save new acceleration value to data array */
	accDataArray[dataIndex] = directionVector / 10;

/** set alarm flag if new value is above threshold */
	if( ( directionVector / 10 > alarmLimit ) && *ptr_newAlarm == 0 )
	{
			*ptr_newAlarm = 1;											// set alarm flag
			*ptr_alarmIndex = dataIndex;								// save alarm position
	}

}

static void fallAssistant_DeleteGraph( uint8_t gfxCounter, uint8_t dataIndex, uint8_t accDataArray[] )
{
	uint8_t graphOffsetX = ( dataIndex - OLED_SCREEN_WIDTH  );			// x-offset array index of data graph on screen
	uint8_t graphOffsetXp = ( dataIndex - OLED_SCREEN_WIDTH -1 );		// x-offset array index of previous data graph on screen

/** set x-coordinate of graph */
	fallAssistant_pixel.dynamicArea.xCrd = gfxCounter;

/** delete old data line from screen */
	fallAssistant_pixel.img = blackdot_bmp;

	if( accDataArray[graphOffsetXp] <= accDataArray[graphOffsetX])
	{
		for( uint8_t i = ( accDataArray[graphOffsetXp] ); i <= ( accDataArray[graphOffsetX] ); i ++ )
		{
			fallAssistant_pixel.dynamicArea.yCrd = ( GRAPH_Y_POSITION - i );
			GuiDriver_ImageDraw(&fallAssistant_pixel);
		}
	}
	else
	{
		for( uint8_t i = ( accDataArray[graphOffsetXp] ); i > ( accDataArray[graphOffsetX] ); i -- )
		{
			fallAssistant_pixel.dynamicArea.yCrd = ( GRAPH_Y_POSITION - i );
			GuiDriver_ImageDraw(&fallAssistant_pixel);
		}
	}
}

static void fallAssistant_DrawGraph( uint8_t gfxCounter, uint8_t dataIndex, uint8_t accDataArray[], uint8_t alarmLimit )
{
	uint8_t dataIndexOffset = dataIndex - 1;

/** set x-coordinate of graph */
	fallAssistant_pixel.dynamicArea.xCrd = gfxCounter;

/** draw new data line on screen */
	if( accDataArray[dataIndex] < alarmLimit )							// if acceleration value is below threshold line is blue else red
	{
			fallAssistant_pixel.img = bluedot_bmp;
	}
	else
	{
			fallAssistant_pixel.img = reddot_bmp;
	}

	if( accDataArray[dataIndexOffset] <= accDataArray[dataIndex])		// if data line rises up
	{
		for( uint8_t i = ( accDataArray[dataIndexOffset] ); i <= ( accDataArray[dataIndex] ); i ++ )
		{
			fallAssistant_pixel.dynamicArea.yCrd = ( GRAPH_Y_POSITION - i );
			GuiDriver_ImageDraw(&fallAssistant_pixel);
		}
	}
	else																// else data line falls down
	{
		for( uint8_t i = ( accDataArray[dataIndexOffset] ); i > ( accDataArray[dataIndex] ); i -- )
		{
			fallAssistant_pixel.dynamicArea.yCrd = ( GRAPH_Y_POSITION - i );
			GuiDriver_ImageDraw(&fallAssistant_pixel);
		}
	}
}

static void fallAssistant_DrawMax( uint8_t accMaxValue )
{
	fallAssistant_charOut.dynamicArea.xCrd = 64;
	fallAssistant_charOut.dynamicArea.yCrd = 21;
	fallAssistant_charOut.textProperties.alignParam = OLED_TEXT_ALIGN_RIGHT;
	fallAssistant_charOut.textProperties.fontColor = GUI_COLOR_BLUE_1;
	GuiDriver_LabelSetCaption( &fallAssistant_charOut, (uint8_t*)"Max" );
	GuiDriver_LabelDraw( &fallAssistant_charOut );
	fallAssistant_charOut.textProperties.fontColor = GUI_COLOR_WHITE;
	snprintf( (char*)fallAssistant_charOut.caption, 6, "%i.%01i", accMaxValue / 10, accMaxValue % 10 );
	fallAssistant_charOut.dynamicArea.yCrd = 34;
	fallAssistant_charOut.textProperties.alignParam = OLED_TEXT_ALIGN_RIGHT;
	GuiDriver_LabelDraw( &fallAssistant_charOut );
}

static void fallAssistant_DrawAvg( uint8_t accAvgValue )
{
	fallAssistant_charOut.dynamicArea.xCrd = 3;
	fallAssistant_charOut.dynamicArea.yCrd = 21;
	fallAssistant_charOut.textProperties.alignParam = OLED_TEXT_ALIGN_LEFT;
	fallAssistant_charOut.textProperties.fontColor = GUI_COLOR_GREEN;
	GuiDriver_LabelSetCaption( &fallAssistant_charOut, (uint8_t*)"Avg" );
	GuiDriver_LabelDraw( &fallAssistant_charOut );
	fallAssistant_charOut.dynamicArea.xCrd = 3;
	fallAssistant_charOut.dynamicArea.yCrd = 34;
	fallAssistant_charOut.textProperties.fontColor = GUI_COLOR_WHITE;
	fallAssistant_charOut.textProperties.alignParam = OLED_TEXT_ALIGN_LEFT;
	snprintf( (char*)fallAssistant_charOut.caption, 6, "%i.%01i", accAvgValue / 10, accAvgValue % 10 );
	GuiDriver_LabelDraw( &fallAssistant_charOut );
}

static void fallAssistant_DrawSum( uint16_t alarmSum )
{
	fallAssistant_charOut.dynamicArea.xCrd = 34;
    fallAssistant_charOut.dynamicArea.yCrd = 21;
    fallAssistant_charOut.textProperties.alignParam = OLED_TEXT_ALIGN_CENTER;
    fallAssistant_charOut.textProperties.fontColor = GUI_COLOR_RED;
    GuiDriver_LabelSetCaption( &fallAssistant_charOut, (uint8_t*)"Sum" );
    GuiDriver_LabelDraw( &fallAssistant_charOut );
    fallAssistant_charOut.textProperties.fontColor = GUI_COLOR_WHITE;
    snprintf( (char*)fallAssistant_charOut.caption, 9, "%i.%01i", alarmSum / 10, alarmSum % 10 );
    fallAssistant_charOut.dynamicArea.yCrd = 34;
    fallAssistant_charOut.textProperties.alignParam = OLED_TEXT_ALIGN_CENTER;
    GuiDriver_LabelDraw( &fallAssistant_charOut );
}

static void fallAssistant_Blink( bool blinkFlag )
{

	if( blinkFlag )
		{
			fallAssistant_pixel.img = red_bmp;
		}

	else
		{
			fallAssistant_pixel.img = white_bmp;
		}

		fallAssistant_pixel.dynamicArea.xCrd = 62;
		fallAssistant_pixel.dynamicArea.yCrd = 82;
		GuiDriver_ImageDraw( &fallAssistant_pixel );

}

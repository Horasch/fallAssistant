/**
 * \file fallAssistant_objects.c
 * \version 1.00
 * \Juri Kuebler
 * \08.2016
 */

#include "screens_common.h"
#include "fallAssistant_private.h"
#include "fallAssistant.h"

static guiScreen_t
    fallAssistant_mainScreen;

guiScreen_t
    fallAssistant_coverScreen =
    {
        .navigation =
        {
            .up     = &flashlightScreen,
            .down   = &fallConfig_coverScreen,
            .left   = &appsScreen,
            .right  = &fallAssistant_mainScreen
        },

        .image = blank_cover_bmp,

        .initFunction        = fallAssistant_Cover_Init,
        .createTaskFunction  = NULL,
        .destroyTaskFunction = NULL
    };

static guiScreen_t
    fallAssistant_mainScreen =
    {
        .navigation =
        {
            .up     = NULL,
            .down   = NULL,
            .left   = &fallAssistant_coverScreen,
            .right  = NULL
        },

        .image = blank_screen_bmp,

        .initFunction        = fallAssistant_Init,
        .createTaskFunction  = fallAssistant_CreateTasks,
        .destroyTaskFunction = fallAssistant_DestroyTasks
    };


/** labels */

guiLabel_t fallAssistant_alarm_label =
{
    .dynamicArea =
    {
		.xCrd   = 23,
		.yCrd   = 42,
        .width  = 50,
        .height = 28
    },
    .textProperties =
    {
        .font       = guiFont_Tahoma_16_Regular,
        .fontColor  = GUI_COLOR_ORANGE,
        .alignParam = OLED_TEXT_ALIGN_CENTER,
        .background = blank_screen_bmp
    },
    .caption = NULL,
    .captionLength = 6
};

guiLabel_t fallAssistant_charOut =
{
    .dynamicArea =
    {
        .xCrd   = 3,
        .yCrd   = 62,
        .width  = 30,
        .height = 13
    },

    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_WHITE,
        .alignParam = OLED_TEXT_ALIGN_LEFT,
        .background = blank_screen_bmp
    },

    .caption = NULL,
    .captionLength = 6
};

guiImage_t
    fallAssistant_pixel =
    {
        .dynamicArea =
        {
            .xCrd   = 47,
            .yCrd   = 54
        },

        .img = white_bmp
    };

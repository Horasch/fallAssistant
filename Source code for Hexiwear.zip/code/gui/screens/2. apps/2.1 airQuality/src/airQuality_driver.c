/*
 * air.Quality_driver.c
 *
 *  Created on: 03.09.2016
 *      Author: Juri
 */

#include "airQuality.h"
#include "airQuality_private.h"
#include "screens_common.h"


/** private variables */

static task_handler_t
    airQuality_taskHandler;

static hostInterface_packet_t
        airQuality_packet;

static packet_pushTarget_t
    appBackupList[PACKET_ALL];

static packet_pushTarget_t
    appPushTarget = PACKET_PUSH_OLED;

/** private declarations */

static void airQuality_AppTask();

/** public API */

/**
 * initialize the weather station task
 * @param param optional parameter
 */
void airQuality_Cover_Init( void* param )
{
	screen_imgIcon.img = airQuality_icon_bmp;
	GuiDriver_ImageAddToScr( &screen_imgIcon );
   	GuiDriver_ImageAddToScr( &screen_buttonOk );

    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Air Quality" );
    GuiDriver_LabelDraw( &screen_label );
}

void airQuality_Init( void* param )
{
	screen_imgIcon.img = airQuality_icon_gray_bmp;
	GuiDriver_ImageAddToScr( &screen_imgIcon );

    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Air Quality" );
    GuiDriver_LabelDraw( &screen_label );

	GuiDriver_LabelCreate( &airQuality_labelValue );

	if ( false == gui_sensorTag_IsActive() )
	{
		GuiDriver_RegisterMinPollDelay( 100 );
		GuiDriver_RegisterForSensors( PACKET_AIR, 100, false );
	}

	else
	{
		GuiDriver_RegisterForSensors( PACKET_AIR,  -1, false );
	}

    HEXIWEAR_SetBackupList( (packet_pushTarget_t*)appBackupList );
    HEXIWEAR_SetTargetApp ( appPushTarget );

}

/**
 * create tasks for the weather station app
 * @param param optional parameter
 */
void airQuality_CreateTasks( void* param )
{
    osa_status_t
        taskStatus = OSA_TaskCreate(
        								airQuality_AppTask,
                                        (uint8_t*) "air quality app",
                                        AIR_QUALITY_STACK_SIZE,
                                        NULL,
                                        AIR_QUALITY_PRIO,
                                        (task_param_t)0,
                                        false,
                                        &airQuality_taskHandler
                                    );

    if ( kStatus_OSA_Success != taskStatus )
    {
        catch( CATCH_INIT );
    }
}

/**
 * destroy tasks in the weather station app
 * @param param optional parameter
 */
void airQuality_DestroyTasks( void* param )
{
    OSA_TaskDestroy( airQuality_taskHandler );
    GuiDriver_UnregisterFromSensors( PACKET_AIR, false );

    OLED_DestroyDynamicArea();

    GuiDriver_LabelDestroy( &screen_label );
    GuiDriver_LabelDestroy( &airQuality_labelValue );

    HEXIWEAR_SetBackupList( NULL );
    HEXIWEAR_SetTargetApp ( PACKET_PUSH_NONE );

    power_EnablePowerSave();
}

/** private API */

/**
 * GUI weather station task
 */
static void airQuality_AppTask()
{
		mE_t sensorValue_old = 0;

		power_DisablePowerSave();

	    while(1)
	    {

	  	  gui_status_t	clickStatus = GuiDriver_QueueMsgGet( &airQuality_packet , OSA_WAIT_FOREVER );


	  	  if( GUI_STATUS_SUCCESS == clickStatus )
	  	    {
	  	        if( packetType_airQuality 	!= airQuality_packet.type )
	  	        {
	  	            continue;
	  	        }
	  	    }


	    // Extract data
	  	  mE_t sensorValue = (mE_t)( airQuality_packet.data[0] | (mE_t)airQuality_packet.data[1] << 8 );

			if (sensorValue_old != sensorValue)
			{
				  snprintf( (char*)airQuality_labelValue.caption, 6, "%d", sensorValue );
				  GuiDriver_LabelDraw(&airQuality_labelValue);
			}
			sensorValue_old = sensorValue;
	    }
}

/*
 * airQuality_objects.c
 *
 *  Created on: 03.09.2016
 *      Author: Juri
 */
#include "screens_common.h"
#include "airQuality_private.h"
#include "airQuality.h"

static guiScreen_t
	airQuality_mainScreen;

guiScreen_t
	airQuality_coverScreen =
    {
        .navigation =
        {
            .up     = &gui_weatherStation_coverScreen,
            .down   = &gui_motionControl_coverScreen,
            .left   = &appsScreen,
            .right  = &airQuality_mainScreen
        },

        .image = blank_cover_bmp,

        .initFunction        = airQuality_Cover_Init,
        .createTaskFunction  = NULL,
        .destroyTaskFunction = NULL
    };

static guiScreen_t
    airQuality_mainScreen =
    {
        .navigation =
        {
            .up     = NULL,
            .down   = NULL,
            .left   = &airQuality_coverScreen,
            .right  = NULL
        },

        .image = blank_screen_bmp,

        .initFunction        = airQuality_Init,
        .createTaskFunction  = airQuality_CreateTasks,
        .destroyTaskFunction = airQuality_DestroyTasks
    };

/** labels */

/** Measured Value */
guiLabel_t airQuality_labelValue =
{
    .dynamicArea =
    {
        .xCrd   = 53,
        .yCrd   = 79,
        .width  = 43,
        .height = 15
    },
    .textProperties =
    {
        .font       = guiFont_Tahoma_8_Regular,
        .fontColor  = GUI_COLOR_BLUE_2,
        .alignParam = OLED_TEXT_ALIGN_LEFT,
        .background = blank_screen_bmp
    },
    .caption = NULL,
    .captionLength = 6
};





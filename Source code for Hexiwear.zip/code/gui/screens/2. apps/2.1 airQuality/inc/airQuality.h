/**
 * \file airQuality.h
 * \version 1.00
 * \author Juri K�bler
 */

#pragma once

#include "gui_driver.h"

#define AIR_QUALITY_STACK_SIZE ( 0x500 )
#define AIR_QUALITY_PRIO       ( HEXIWEAR_GUI_PRIO )

extern guiScreen_t
    airQuality_coverScreen;

void airQuality_Cover_Init();
void airQuality_Init();
void airQuality_CreateTasks();
void airQuality_DestroyTasks();

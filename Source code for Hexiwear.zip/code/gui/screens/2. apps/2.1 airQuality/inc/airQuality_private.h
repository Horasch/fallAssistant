/**
 * \file airQuality_private.h
 * \author Juri K�bler
 */

#pragma once

#include "gui_driver.h"
#include <stdint.h>

extern const uint8_t
    airQuality_icon_bmp[ 5006 ],
    airQuality_icon_gray_bmp[ 5006 ];

extern guiLabel_t
    airQuality_labelValue;

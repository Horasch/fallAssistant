/*
 * battery driver.h
 *
 *  Created on: 09.07.2016
 *      Author: Juri
 */

/** includes */

#include "gui_driver.h"
#include "battery_private.h"
#include "battery.h"
#include "screens_common.h"
#include "TSL_driver.h"
#include "ambilight.h"


/** private variables */

static bool isBatteryCharging = false;

static uint8_t battery_level;
static uint8_t ambilight_level;

static hostInterface_packet_t battery_dataPacket;

static task_handler_t battery_taskHandler;

/** private function declarations */

static void battery_UpdateBatteryLevel(uint8_t level);
static void battery_AppTask(task_param_t param);

/**
 * initialize the battery cover screen
 * @param param optional parameter
 */
void battery_Cover_Init( void *param )
{
	screen_imgIcon.img = battery_icon_full_bmp;
	GuiDriver_ImageAddToScr( &screen_imgIcon );
   	GuiDriver_ImageAddToScr( &screen_buttonOk );

    GuiDriver_LabelCreate( &screen_label );
    GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Battery" );
    GuiDriver_LabelDraw( &screen_label );
}

/**
 * initialize the battery screen
 * @param param optional parameter
 */
void battery_Init( void *param )
{

  GuiDriver_ImageAddToScr(&screen_imgIcon);
  GuiDriver_LabelCreate( &battery_labelVoltage );

  GuiDriver_LabelCreate( &screen_label );
  GuiDriver_LabelSetCaption( &screen_label, (uint8_t*)"Battery" );
  GuiDriver_LabelDraw( &screen_label );

  TSL_Enable ();
  // Register for packets we want to receive

	if ( false == gui_sensorTag_IsActive() )
	{
		GuiDriver_RegisterMinPollDelay( 100 );
		GuiDriver_RegisterForSensors( PACKET_BAT, 100, false );
		GuiDriver_RegisterForSensors( PACKET_LUX, 100, true );
	}

	else
	{
		GuiDriver_RegisterForSensors( PACKET_BAT,  -1, false );
		GuiDriver_RegisterForSensors( PACKET_LUX,  -1, true );
	}
}

/**
 * create tasks in the battery screen app
 * @param param optional parameter
 */
void battery_CreateTasks( void *param )
{
  osa_status_t
  	  taskStatus = OSA_TaskCreate (
                            		battery_AppTask,
									(uint8_t *) "battery app",
									BATTERY_STACK_SIZE,
									NULL,
									BATTERY_PRIO,
									(task_param_t)0,
									false,
									&battery_taskHandler
  	  	  	  	  	  	  	  );

  if ( kStatus_OSA_Success != taskStatus )
  {
    catch( CATCH_INIT );
  }
}

/**
 * destroy current running tasks in the battery screen app
 * @param param optional parameter
 */
void battery_DestroyTasks( void *param )
{

  OSA_TaskDestroy( battery_taskHandler );

  GuiDriver_UnregisterFromSensors( PACKET_BAT, false );
  GuiDriver_UnregisterFromSensors( PACKET_LUX, false );

  OLED_DestroyDynamicArea();

  GuiDriver_LabelCreate( &screen_label );
  GuiDriver_LabelDestroy( &battery_labelVoltage );
  TSL_Disable();
  power_EnablePowerSave();

}


/**
 * wait for packets and analyze data
 * @param param optional parameter
 */

static void battery_AppTask(task_param_t param)
{
	  power_DisablePowerSave();

	while(1)
	{

	  battery_CheckBatteryStatus();

	  gui_status_t	clickStatus = GuiDriver_QueueMsgGet( &battery_dataPacket , OSA_WAIT_FOREVER );


	  if( GUI_STATUS_SUCCESS == clickStatus )
	    {
	        if(			( packetType_batteryLevel 	!= battery_dataPacket.type )
	        		&&  ( packetType_ambiLight   	!= battery_dataPacket.type )
	          )
	        {
	            continue;
	        }
	    }


    // Extract data
	  mE_t sensorValue = (mE_t)( battery_dataPacket.data[0] | (mE_t)battery_dataPacket.data[1] << 8 );

	  switch (battery_dataPacket.type)
	  {
	  	  // Battery Service
	  	  case packetType_batteryLevel:
	  	  {
	  		  battery_level = (uint8_t)sensorValue;
	  		  break;

	  	  }
      	  // Ambilight Service
	  	  case packetType_ambiLight:
	  	  {

	  		  ambilight_level = (uint8_t)sensorValue;
	  		  break;

	  	  }
	  	  default: {}

	  }


	  ambilight_UpdateBrightnessLevel(ambilight_level);


	  if ( true == battery_IsBatteryCharging() )
	  {
		  screen_imgIcon.img = battery_icon_charge_bmp;
		  GuiDriver_ImageDraw( &screen_imgIcon );
	  }
	  else
	  {
		  battery_UpdateBatteryLevel(battery_level);
		  sensor_ResetPacketcounter( PACKET_BAT );
	  }

	  snprintf( (char*)battery_labelVoltage.caption, 6, "%d %%", battery_level );
	  GuiDriver_LabelDraw(&battery_labelVoltage);
	}

}


/**
 * update the battery level on GUI
 * @param level battery level in percents
 */
static void battery_UpdateBatteryLevel(uint8_t level)
{
  const uint8_t *img;

  if ( level >= 67 )
  {
	img = battery_icon_full_bmp;
  }
  else if ( level >= 33 )
  {
    img = battery_icon_half_bmp;
  }
  else if ( level >= 5 )
  {
    img = battery_icon_fourth_bmp;
  }
  else
  {
	img = battery_icon_empty_bmp;
  }

  if( screen_imgIcon.img != img )
  {
	  screen_imgIcon.img = img;
    GuiDriver_ImageDraw(&screen_imgIcon);
  }
}

/**
 * check for the charging status in the interrupt
 */
void battery_CheckBatteryStatus()
{

    uint8_t
       chargePinVal = ( GPIOC_PDIR & ( 1 << 12 ) ) >> 12;

   if ( 0 == chargePinVal )
   {
        // indicate that the battery is charging
        isBatteryCharging = true;
        // power_DisablePowerSave();
   }

   else
   {
        // no charging, display normal battery levels
        isBatteryCharging = false;
//        power_EnablePowerSave();
   }

}

/**
 * return battery charge status flag
 * @return charge status flag
 */
bool battery_IsBatteryCharging()
{
	return isBatteryCharging;
}



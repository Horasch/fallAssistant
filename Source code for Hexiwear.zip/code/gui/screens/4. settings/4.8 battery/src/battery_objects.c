/*
 * battery_objects.h
 *
 *  Created on: 09.07.2016
 *      Author: Juri
 */

#include "screens_common.h"
#include "battery_private.h"
#include "battery.h"

guiScreen_t battery_mainScreen;

guiScreen_t
    battery_coverScreen =
    {
        .navigation =
        {
            .up     = &resetScreen,
            .down   = &bluetoothScreen,
            .left   = &settingsScreen,
            .right  = &battery_mainScreen
        },

        .image = blank_cover_bmp,

        .initFunction        = battery_Cover_Init,
        .createTaskFunction  = NULL,
        .destroyTaskFunction = NULL
    };

guiScreen_t battery_mainScreen =
    {
        .navigation =
        {
            .up     = NULL,
            .down   = NULL,
            .left   = &battery_coverScreen,
            .right  = NULL
        },

        .image = blank_screen_bmp,

        .initFunction        = battery_Init,
        .createTaskFunction  = battery_CreateTasks,
        .destroyTaskFunction = battery_DestroyTasks
    };

/** labels */

/** Battery Voltage */
guiLabel_t battery_labelVoltage =
{
    .dynamicArea =
    {
    .xCrd   = 53,
    .yCrd   = 79,
    .width  = 43,
    .height = 15
    },

    .textProperties =
    {
    .font       = guiFont_Tahoma_8_Regular,
    .fontColor  = GUI_COLOR_GREEN,
    .alignParam = OLED_TEXT_ALIGN_LEFT,
    .background = blank_screen_bmp
    },

    .caption       = NULL,
    .captionLength = 6
};

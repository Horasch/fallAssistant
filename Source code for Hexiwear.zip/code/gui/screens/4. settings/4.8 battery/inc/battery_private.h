/*
 * battery_private.h
 *
 *  Created on: 09.07.2016
 *      Author: Juri
 */

#pragma once

#include <stdint.h>
#include "gui_driver.h"



// Resources

extern const uint8_t battery_icon_empty_bmp[ 5006 ];
extern const uint8_t battery_icon_fourth_bmp[ 5006 ];
extern const uint8_t battery_icon_full_bmp[ 5006 ];
extern const uint8_t battery_icon_charge_bmp[ 5006 ];
extern const uint8_t battery_icon_half_bmp[ 5006 ];


// Objects
extern guiLabel_t battery_labelVoltage;




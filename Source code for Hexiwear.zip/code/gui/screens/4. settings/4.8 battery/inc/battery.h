/*
 * battery.h
 *
 *  Created on: 09.07.2016
 *      Author: Juri
 */

#pragma once

#include "gui_driver.h"

#define BATTERY_STACK_SIZE ( 0x500 )
#define BATTERY_PRIO       ( HEXIWEAR_GUI_PRIO )

// screens
extern guiScreen_t battery_coverScreen;

/**
 * check charging status on the interrupt
 */
void battery_CheckBatteryStatus();
bool battery_IsBatteryCharging();

// Callbacks
void battery_Init( void *param );
void battery_Cover_Init( void *param );
void battery_CreateTasks(void *param);
void battery_DestroyTasks(void *param);

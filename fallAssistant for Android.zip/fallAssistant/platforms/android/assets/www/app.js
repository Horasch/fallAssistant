
app = {
};

app.connecting = false;
app.device = false;
app.timer = false;
app.alarmState = false;
app.onlineTimer = [0,0,0];
app.emergencyNumber = false;
app.accelerationSamples = [];
app.batterySamples = [];
app.rate = 0.85;

app.BATTERY_SERVICE = "0000180f-0000-1000-8000-00805f9b34fb";
app.BATTERY_CHARACTERISTIC = "00002a19-0000-1000-8000-00805f9b34fb";

app.MOTION_SERVICE = "00002000-0000-1000-8000-00805f9b34fb";
app.MOTION_ACCELEROMETER = "00002001-0000-1000-8000-00805f9b34fb";

app.MODE_SERVICE = "00002040-0000-1000-8000-00805f9b34fb";
app.MODE_CHARACTERISTIC = "00002041-0000-1000-8000-00805f9b34fb";

app.ALERT_SERVICE = "00002030-0000-1000-8000-00805f9b34fb";
app.ALERT_OUT = "00002032-0000-1000-8000-00805f9b34fb";


app.initialize = function () {
    document.addEventListener(
		'deviceready',
		function () { evothings.scriptsLoaded(app.onDeviceReady);},
		false);
};

app.status = function (text) {
    if (app.oldStatus == text) return;
    app.oldStatus = text;
    console.log(text);
    document.getElementById("status").innerHTML = text;
};

app.onDeviceReady = function () {
    app.status("Ready");
    console.log(navigator.contacts);

    TTS
    .speak({
        text: 'Welcome, to fall assistant! Please set first your emergency contact',
        locale: 'en-US',
        rate: app.rate
    }, function () {
        console.log('Welcome, to fall assistant! Please set first your emergency contact');
    }, function (reason) {
        console.log(reason);
    });
 };

/*app.tryButton = function () {

};*/

app.callEmergencyNumber = function () {
    window.plugins.CallNumber.callNumber(onSuccess, onError, app.emergencyNumber, true);
    function onSuccess(result) {
        console.log("Success:" + result);
        app.getPhoneCallState(app.alarmState);
    }
    function onError(result) {
        console.log("Error:" + result);
    }

    app.getPhoneCallState(app.alarmState);
}

app.getPhoneCallState = function (state) {
    do {
        if (window.PhoneCallTrap) {
            PhoneCallTrap.onCall(function (state) {
                console.log("CHANGE STATE: " + state);

                switch (state) {
                    case "RINGING":
                        console.log("Phone is ringing");
                        app.alarmState = false;
                        AudioToggle.setAudioMode(AudioToggle.NORMAL);
                        break;
                    case "OFFHOOK":
                        console.log("Phone is off-hook");
                        app.alarmState = true;
                        AudioToggle.setAudioMode(AudioToggle.SPEAKER);
                        break;

                    case "IDLE":
                        console.log("Phone is idle");
                        app.alarmState = false;
                        AudioToggle.setAudioMode(AudioToggle.NORMAL);
                        break;
                }
            });
        }
    } while ( app.alarmState )
}


app.onConnectButton = function () {
    if (app.device) return;
    evothings.easyble.stopScan();
    app.status("Scanning...");
    evothings.easyble.startScan(
		function (device) {
		    if (app.connecting) return;

		    if (app.isHexiwear(device)) {
		        evothings.easyble.stopScan();
		        app.connect(device);
		    }
		},
		function (errorCode) {
		    // Report error.
		    callbackFun(null, errorCode);
		},
		{ allowDuplicates: false }
	);
};

app.isHexiwear = function (device) {
    return device.name == "HEXIWEAR";
};

app.getContact = function () {
    navigator.contacts.pickContact(function (contact) {
        console.log('The following contact has been selected:' + JSON.stringify(contact));
        var s = "";
        s += contact.displayName + "<br/>";

        TTS.speak('Thank you!', function () {
            console.log('Thank you!');
        }, function (reason) {
            console.log(reason);
        });
        
        if (contact.phoneNumbers && contact.phoneNumbers.length) {
            s += "Phonenumber: " + contact.phoneNumbers[0].value;
        }
        app.emergencyNumber = contact.phoneNumbers[0].value;
        document.getElementById("alarmContact").innerHTML = s;
        app.onConnectButton();
    }, function (err) {
        console.log('Error: ' + err);
    });
};

app.disconnect = function () {
    if (app.timer) {
        clearInterval(app.timer);
        app.timer = false;
    }
    if (app.device) {
        app.device.close();
        app.device = false;
        app.connecting = false;
        app.status("Disconnected");
    }
};

app.connect = function (device) {
    app.disconnect();
    app.connecting = true;
    app.device = device;
    app.status("Connecting...");
    device.connect(
		function (device) {
		    app.connecting = false;
		    app.status("Reading services...");
		    device.readServices(
				function (device) {
				    app.startNotifications();

                    TTS.speak('Connected to hexiwear', function () {
				        console.log('Connected to hexiwear');
				    }, function (reason) {
				        console.log(reason);
				    });
				},
				function (errorCode) {
				    app.status("readServices error: " + errorCode);
				});
		},
		function (errorCode) {
		    app.status("Connect error: " + errorCode);
		    if (errorCode == 133 || 8) {
		        app.disconnect();
		        app.onConnectButton();
		    }
		});
};

app.convertHexData = function (data) {
    return "0x" + evothings.util.typedArrayToHexString(data);
};

app.convert3x16bitData = function (data) {
    var d = new Int16Array(data);
    var ax = d[0] / 100.0;
    var ay = d[1] / 100.0;
    var az = d[2] / 100.0;
    var vector = Math.sqrt(ax * ax + ay * ay + az * az);
    app.drawAccelerationDiagram({ x: vector });

    return "X: " + ax + " , Y: " + ay + " , Z: " + az;
};

app.convert10x8bitData = function (data) {
    var d = new Uint8Array(data);
    var string = d[0] + ", ";

    TTS.speak('Fall detected! Starting emergency call!', function () {
        console.log('Fall detected!');
    }, function (reason) {
        console.log(reason);
    });
    setTimeout(app.callEmergencyNumber, 3000);

    if (d[1] < 10) {
        string += "0" + d[1] + ":";
    }
    else {
        string += d[1] + ":";
    }
    if (d[2] < 10) {
        string += "0" + d[2] + ":";
    }
    else {
        string += d[2] + ":";
    }
    if (d[3] < 10) {
        string += "0" + d[3] + ", ";
    }
    else {
        string += d[3] + ", ";
    }
    return  string + d[4] + "." + d[5] + "." + d[6];
};

app.convert8bitPercentageData = function (data) {
    var b = new Uint8Array(data)[0];
    app.drawBatteryDiagram({ x: b });

    if (b < 10) {
        TTS.speak('Battery low!', function () {
            console.log('Battery low!');
        }, function (reason) {
            console.log(reason);
        });
    }


    return b + "%";
};

app.convertHumidityData = function (data) {
    return (new Uint16Array(data)[0]) / 100.0 + "%";
};

app.convertTemperatureData = function (data) {
    return (new Int16Array(data)[0]) / 100.0 + " &deg;C";
};

app.convertPressureData = function (data) {
    return (new Uint16Array(data)[0]) / 100.0 + " Pa";
};

app.convertHeartData = function (data) {
    return new Uint8Array(data)[0] + " bpm";
};

app.convert16bitUnsignedData = function (data) {
    return new Uint16Array(data)[0];
};

app.convertOnlineTimerToString = function (data) {
    var timerString = "";

    if (app.onlineTimer[2] < 10) {
        timerString += " 0" + app.onlineTimer[2];
    }
    else {
        timerString += " " + app.onlineTimer[2];
    }
    if (app.onlineTimer[1] < 10) {
        timerString += ":0" + app.onlineTimer[1];
    }
    else {
        timerString += ":" + app.onlineTimer[1];
    }
    if (app.onlineTimer[0] < 10) {
        timerString += ":0" + app.onlineTimer[0];
    }
    else {
        timerString += ":" + app.onlineTimer[0];
    }
    return timerString;
};

app.modes = ['Idle', 'Watch', 'Sensor Tag', 'Weather', 'Motion Accel', 'Motion Gyro', 'Pedometer'];
app.convertModeData = function (data) {
    var v = new Uint8Array(data)[0];
    if (v < app.modes.length) {
        return v + " (" + app.modes[v] + ")";
    } else {
        return "Unknown mode " + v;
    }
};

app.handleData = function(elementId, data, converter) {
    var string = converter(data);
//    console.log(elementId+": "+string);
    document.getElementById(elementId).innerHTML = string;
};

app.readCharacteristic = function(service, characteristic, elementId, converter) {
    app.device.readCharacteristic(service, characteristic,
		function(data) {
		    app.status("Active");
		    app.handleData(elementId, data, converter);
		},
		function(errorCode) {
		    app.status("readCharacteristic error: "+errorCode);
		});
};

app.enableNotification = function(service, characteristic, elementId, converter) {
    app.device.enableNotification(service, characteristic,
		function(data) {
		    app.status("Active");
		    app.handleData(elementId, data, converter);
		},
		function(errorCode) {
		    app.status("enableNotification error: "+errorCode);
		});
};


app.startNotifications = function() {
    app.status("Reading data...");
    //	app.readCharacteristic(app.INFO_SERVICE, app.INFO_FIRMWARE, "firmware", evothings.ble.fromUtf8);
    //	app.readCharacteristic(app.INFO_SERVICE, app.INFO_SERIAL, "serial", app.convertHexData);
    app.readCharacteristic(app.BATTERY_SERVICE, app.BATTERY_CHARACTERISTIC, "battery", app.convert8bitPercentageData);
    //  app.enableNotification(app.MOTION_SERVICE, app.MOTION_ACCELEROMETER, "accel", app.convert3x16bitData);
    app.enableNotification(app.BATTERY_SERVICE, app.BATTERY_CHARACTERISTIC, "battery", app.convert8bitPercentageData);
    app.enableNotification(app.ALERT_SERVICE, app.ALERT_OUT, "alarms", app.convert10x8bitData);

    app.timer = window.setInterval(app.pollAcceleration, 500);
    app.timer = window.setInterval(app.pollOnlineTimer, 1000);
};

app.pollAcceleration = function () {
    app.readCharacteristic(app.MOTION_SERVICE, app.MOTION_ACCELEROMETER, "accel", app.convert3x16bitData);
};

app.pollOnlineTimer = function () {
    app.onlineTimer[0]++;
    if (app.onlineTimer[0] < 60) {
        app.handleData('onlinetimer', app.onlineTimer, app.convertOnlineTimerToString);
    }
    else if ((app.onlineTimer[0] == 60) && (app.onlineTimer[1] < 60)) {
        app.onlineTimer[1]++;
        app.onlineTimer[0] = 0;
        app.handleData('onlinetimer', app.onlineTimer, app.convertOnlineTimerToString);
    }
    else if ((app.onlineTimer[0] == 60) && (app.onlineTimer[1] == 60) && (app.onlineTimer[2] < 24)) {
        app.onlineTimer[2]++;
        app.onlineTimer[0] = 0;
        app.onlineTimer[1] = 0;
        app.handleData('onlinetimer', app.onlineTimer, app.convertOnlineTimerToString);
    }
};


// Draw diagram to canvas.
app.drawAccelerationDiagram = function (values) {
    var canvas = document.getElementById('acccanvas');
    var context = canvas.getContext('2d');

    // Add recent values.
    app.accelerationSamples.push(values);

    // Remove data points that do not fit the canvas.
    if (app.accelerationSamples.length > canvas.width) {

        app.accelerationSamples.splice(0, (app.accelerationSamples.length - canvas.width));
    }

    // Value is an accelerometer reading between -1 and 1.
    function calcDiagramY(value) {

        // Return Y coordinate for this value.
        var diagramY = (canvas.height - (value * canvas.height / 5));
        return diagramY;
    }

    function drawLine(axis, color) {

        context.strokeStyle = color;
        context.beginPath();
        var lastDiagramY = calcDiagramY(
			app.accelerationSamples[app.accelerationSamples.length - 1][axis]);
        context.moveTo(0, lastDiagramY);
        var x = 1;
        for (var i = app.accelerationSamples.length - 2; i >= 0; i--) {
            var y = calcDiagramY(app.accelerationSamples[i][axis]);
            context.lineTo(x, y);
            x++;
        }
        context.stroke();
    }

    // Clear background.
    context.clearRect(0, 0, canvas.width, canvas.height);

    // Draw lines.
    drawLine('x', '#0000ff');
};


// Draw diagram to canvas.
app.drawBatteryDiagram = function (values) {
    var canvas = document.getElementById('batterycanvas');
    var context = canvas.getContext('2d');

    // Add recent values.
    app.batterySamples.push(values);

    // Remove data points that do not fit the canvas.
    if (app.batterySamples.length > canvas.width) {

        app.batterySamples.splice(0, (app.batterySamples.length - canvas.width));
    }

    // Value is an accelerometer reading between -1 and 1.
    function calcDiagramY(value) {

        // Return Y coordinate for this value.
        var diagramY = (canvas.height - value);
        return diagramY;
    }

    function drawLine(axis, color) {

        context.strokeStyle = color;
        context.beginPath();
        var lastDiagramY = calcDiagramY(
			app.batterySamples[app.batterySamples.length - 1][axis]);
        context.moveTo(0, lastDiagramY);
        var x = 1;
        for (var i = app.batterySamples.length - 2; i >= 0; i--) {
            var y = calcDiagramY(app.batterySamples[i][axis]);
            context.lineTo(x, y);
            x++;
        }
        context.stroke();
    }

    // Clear background.
    context.clearRect(0, 0, canvas.width, canvas.height);

    // Draw lines.
    drawLine('x', '#00ff00');
};

app.initialize();
